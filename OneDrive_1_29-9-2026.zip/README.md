# Sistema Contable — REPASTADORA DEL SUR, S.A.

> Sistema de contabilidad empresarial con inteligencia artificial, OCR y dashboard interactivo.

## 📋 Descripción

Sistema contable completo desarrollado en Python para **REPASTADORA DEL SUR, S.A.**, una empresa ganadera nicaragüense. Incluye:

- 📊 **Dashboard Streamlit** con KPIs financieros en tiempo real
- 🗄️ **Base de datos SQLite** con 135 cuentas del catálogo
- 📝 **Partida doble** con validación automática DEBE = HABER
- 📈 **Reportes financieros** (Balance General, Estado de Resultados, Flujo de Caja)
- 🔍 **OCR** para facturas y comprobantes (Pillow + pytesseract)
- 🤖 **Asistente IA** contable (Ollama + Gemma)
- 📥 **Exportación** a Excel (.xlsx) y PDF

---

## 🗂️ Estructura del Proyecto

```
sistema_contable/
├── app/
│   ├── base_datos/
│   │   ├── database.py          # Modelos SQLAlchemy (CuentaContable, Asiento, etc.)
│   │   ├── migrador.py          # Migración CSV → SQLite
│   │   └── *.csv                # Datos originales
│   ├── contabilidad/
│   │   ├── catalogo.py          # CRUD catálogo de cuentas
│   │   ├── asientos.py          # Registro partida doble
│   │   ├── diario.py            # Libro diario
│   │   ├── mayor.py             # Libro mayor
│   │   └── balance.py           # Balance de comprobación
│   ├── ocr/
│   │   ├── extractor.py         # Extracción de texto (OCR)
│   │   ├── parser.py            # Parser de campos estructurados
│   │   └── validador.py         # Validación de documentos
│   ├── reportes/
│   │   ├── estado_resultados.py # Estado de Resultados
│   │   ├── balance_general.py   # Balance General
│   │   ├── flujo_caja.py        # Flujo de Efectivo
│   │   └── exportar.py          # Exportar a Excel/PDF
│   └── modelos/
│       ├── asistente.py         # Asistente IA (Ollama/Gemma)
│       └── test_ollama.py       # Test de conexión LLM
├── tests/
│   ├── test_catalogo.py
│   ├── test_asientos.py
│   ├── test_reportes.py
│   └── test_conexion_gemma.py
├── dashboard.py                 # Dashboard Streamlit principal
├── .env                         # Configuración (API keys, URLs)
└── requirements.txt
```

---

## ⚙️ Instalación

Consulta la guía completa para instalar o actualizar el sistema en [GUIA_INSTALACION.md](GUIA_INSTALACION.md).

### 1. Clonar y crear entorno virtual

```powershell
cd sistema_contable
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 2. Instalar dependencias

```powershell
pip install -r requirements.txt
pip install streamlit sqlalchemy reportlab plotly
```

### 3. Configurar variables de entorno

Edita el archivo `.env`:

```env
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=gemma4:e4b

# Opcional
GEMINI_API_KEY=tu_api_key_aqui
```

### 4. Instalar Tesseract OCR (para procesamiento de documentos)

Descarga desde: https://github.com/UB-Mannheim/tesseract/wiki  
Instala en: `C:\Program Files\Tesseract-OCR\`

---

## 🚀 Uso

### Instalación local en Windows

Copia la carpeta completa del proyecto en la laptop o PC destino. Debe estar instalado Python 3.10 o superior. Desde la carpeta del proyecto, abre PowerShell y ejecuta:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\instalar_sistema.ps1
```

También puedes hacer doble clic en `instalar_sistema.bat`. El instalador valida el entorno virtual, lo recrea si fue copiado desde otro equipo, instala las dependencias, crea `.env` desde `p.env` si hace falta, inicializa SQLite y crea un acceso directo en el escritorio. No copies la carpeta `venv` entre equipos; el instalador la reconstruirá automáticamente si no es compatible.

Para iniciar el sistema posteriormente, usa el acceso directo o ejecuta:

```powershell
.\iniciar_sistema.ps1
```

El sistema se abrirá en `http://localhost:8501` o en el siguiente puerto disponible. Python 3 debe estar instalado en el equipo. Ollama/Gemma y Tesseract OCR son componentes opcionales para las funciones de IA y OCR.

### Migrar datos desde CSV a SQLite (solo la primera vez)

```powershell
.\venv\Scripts\python.exe app\base_datos\migrador.py
```

### Lanzar el Dashboard

```powershell
.\venv\Scripts\streamlit.exe run dashboard.py
```

El dashboard abrirá en: `http://localhost:8501`

### Ejecutar Tests

```powershell
# Todos los tests
.\venv\Scripts\python.exe -m pytest tests\ -v

# Test individual
.\venv\Scripts\python.exe tests\test_catalogo.py
.\venv\Scripts\python.exe tests\test_asientos.py
.\venv\Scripts\python.exe tests\test_reportes.py
```

---

## 📊 Funcionalidades del Dashboard

| Página | Descripción |
|--------|-------------|
| 🏠 Inicio / KPIs | Total activos, pasivos, capital, utilidad. Gráficas Plotly. |
| 📋 Catálogo de Cuentas | Ver, buscar y filtrar las 135 cuentas. Exportar a Excel. |
| 📝 Registrar Asiento | Formulario de partida doble con validación en tiempo real. |
| 📚 Libro Diario | Historial cronológico de asientos con detalle. |
| 📈 Reportes Financieros | Balance General, Estado de Resultados, Flujo de Caja + exportar. |
| 🔍 OCR — Documentos | Subir imagen de factura y extraer datos automáticamente. |
| 🤖 Asistente IA | Chat con Gemma para consultas financieras en lenguaje natural. |

---

## 🤖 Asistente IA (Ollama)

Para usar el asistente IA debes tener **Ollama** instalado y en ejecución:

```powershell
# Instalar Ollama desde https://ollama.ai
# Descargar el modelo
ollama pull gemma4:e4b
# Iniciar servidor
ollama serve
```

---

## 📦 Dependencias Principales

| Paquete | Uso |
|---------|-----|
| `streamlit` | Dashboard web interactivo |
| `sqlalchemy` | ORM para base de datos SQLite |
| `pandas` | Manejo de datos |
| `plotly` | Gráficas interactivas |
| `openpyxl` | Exportar a Excel |
| `reportlab` | Exportar a PDF |
| `pillow` + `pytesseract` | OCR de imágenes |
| `ollama` | Integración con modelos LLM locales |
| `python-dotenv` | Variables de entorno |

---

## 🏢 Empresa

**REPASTADORA DEL SUR, S.A.**  
Sistema Contable v1.0.0  
Desarrollado con Python 3.14 | Streamlit | SQLAlchemy | Ollama
