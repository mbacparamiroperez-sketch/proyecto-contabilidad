r"""
dashboard.py — Dashboard Principal del Sistema Contable
REPASTADORA DEL SUR, S.A.

Ejecutar con:
    .\venv\Scripts\streamlit.exe run dashboard.py
"""

import sys
import os
from pathlib import Path
from datetime import datetime, date
import io

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from dotenv import load_dotenv

# ─── Configuración de paths ──────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
load_dotenv()

# ─── Configuración de la página ─────────────────────────────────────────────
st.set_page_config(
    page_title="Sistema Contable — REPASTADORA DEL SUR",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

from app.base_datos.empresa import obtener_datos_empresa

datos_empresa_actuales = obtener_datos_empresa()
nombre_empresa = datos_empresa_actuales["nombre"]

# ─── Estilos CSS personalizados ──────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0D47A1 0%, #1565C0 40%, #1976D2 100%);
}
[data-testid="stSidebar"] * { color: white !important; }
[data-testid="stSidebar"] .stRadio label { color: white !important; }

/* Métricas KPI */
[data-testid="metric-container"] {
    background: white;
    border: 1px solid #E3F2FD;
    border-radius: 12px;
    padding: 16px;
    box-shadow: 0 2px 8px rgba(13,71,161,0.08);
    transition: transform 0.2s, box-shadow 0.2s;
}
[data-testid="metric-container"]:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(13,71,161,0.15);
}

/* Título principal */
.titulo-principal {
    background: linear-gradient(135deg, #0D47A1, #1976D2);
    color: white;
    padding: 20px 30px;
    border-radius: 12px;
    margin-bottom: 24px;
}
.titulo-principal h1 { color: white; margin: 0; font-size: 1.8rem; }
.titulo-principal p { color: #BBDEFB; margin: 4px 0 0 0; font-size: 0.95rem; }

/* Secciones */
.seccion-header {
    background: #E3F2FD;
    border-left: 4px solid #1976D2;
    padding: 10px 16px;
    border-radius: 0 8px 8px 0;
    margin: 16px 0 12px 0;
    font-weight: 600;
    color: #0D47A1;
}

/* Botones */
.stButton>button {
    background: linear-gradient(135deg, #1976D2, #0D47A1);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 10px 20px;
    font-weight: 500;
    transition: all 0.2s;
}
.stButton>button:hover {
    background: linear-gradient(135deg, #0D47A1, #0A3875);
    box-shadow: 0 4px 12px rgba(13,71,161,0.3);
    transform: translateY(-1px);
}

/* Tablas */
[data-testid="stDataFrame"] {
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

/* Chat */
.chat-user {
    background: #E3F2FD;
    border-radius: 12px 12px 0 12px;
    padding: 12px 16px;
    margin: 8px 0;
    margin-left: 20%;
    color: #0D47A1;
}
.chat-bot {
    background: #F1F8E9;
    border-radius: 12px 12px 12px 0;
    padding: 12px 16px;
    margin: 8px 0;
    margin-right: 20%;
    color: #1B5E20;
    border-left: 3px solid #4CAF50;
}
</style>
""", unsafe_allow_html=True)


# ─── Importar módulos del sistema ─────────────────────────────────────────────
@st.cache_resource
def inicializar_db():
    """Inicializa la base de datos (crea tablas si no existen)."""
    from app.base_datos.database import crear_tablas, DB_PATH
    crear_tablas()
    return DB_PATH


@st.cache_data(ttl=30)
def _cargar_resumen():
    from app.contabilidad.catalogo import resumen_por_tipo
    return resumen_por_tipo()


@st.cache_data(ttl=30)
def _cargar_catalogo():
    from app.contabilidad.catalogo import obtener_todas
    cuentas = obtener_todas()
    return pd.DataFrame([{
        "Código": c.codigo,
        "Nombre": c.nombre,
        "Clasificación": c.clasificacion or "—",
        "Tipo": c.tipo or "—",
        "Saldo Inicial (C$)": c.saldo_inicial,
        "Saldo Actual (C$)": c.saldo_actual,
    } for c in cuentas])


@st.cache_data(ttl=30)
def _cargar_catalogo_completo():
    from app.contabilidad.catalogo import obtener_todas_incluyendo_inactivas
    cuentas = obtener_todas_incluyendo_inactivas()
    return pd.DataFrame([{
        "Código": c.codigo,
        "Nombre": c.nombre,
        "Clasificación": c.clasificacion or "—",
        "Tipo": c.tipo or "—",
        "Estado": "Activa" if c.activa else "Inactiva",
        "Saldo Inicial (C$)": c.saldo_inicial,
        "Saldo Actual (C$)": c.saldo_actual,
    } for c in cuentas])


@st.cache_data(ttl=30)
def _cargar_asientos(limite=50):
    from app.contabilidad.diario import obtener_libro_diario
    return obtener_libro_diario(limite=limite)


# ─── Sidebar ─────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 📊 Sistema Contable")
    st.markdown(f"**{nombre_empresa}**")
    st.markdown("---")

    pagina = st.radio(
        "Menú principal",
        [
            "🏠 Inicio / KPIs",
            "🏢 Personalizar Empresa",
            "📋 Catálogo de Cuentas",
            "📝 Registrar Asiento",
            "📚 Libro Diario",
            "📖 Libro Mayor / General Ledger",
            "📈 Reportes Financieros",
            "🔍 OCR — Documentos",
            "🤖 Asistente IA",
        ],
        label_visibility="visible"
    )

    st.markdown("---")
    if st.button("🚪 Salir del sistema", key="salir_sistema", width="stretch"):
        st.session_state["confirmar_salida_visible"] = True

    if st.session_state.get("confirmar_salida_visible", False):
        st.warning("El sistema se cerrará en este equipo. Los datos guardados no se eliminarán.")
        col_cancelar, col_confirmar = st.columns(2)
        with col_cancelar:
            if st.button("Cancelar", key="cancelar_salida", width="stretch"):
                st.session_state["confirmar_salida_visible"] = False
                st.rerun()
        with col_confirmar:
            if st.button("Cerrar", key="confirmar_salida_accion", width="stretch"):
                st.cache_data.clear()
                st.cache_resource.clear()
                st.session_state["salida_confirmada"] = True

    if st.session_state.get("salida_confirmada", False):
        st.success("Sesión cerrada correctamente. Ya puedes cerrar esta pestaña del navegador.")
        if st.button("Volver al sistema", key="reanudar_sesion", width="stretch"):
            st.session_state["salida_confirmada"] = False
            st.rerun()
        st.stop()

    st.markdown("---")
    st.markdown(f"<small>📅 {datetime.now().strftime('%d/%m/%Y %H:%M')}</small>", unsafe_allow_html=True)
    st.markdown("<small>🏢 Versión 1.0.0</small>", unsafe_allow_html=True)
    st.markdown("<small>Sistema diseñado por Ramiro Antonio Pérez Molina, CPA.<br>Todos los derechos reservados.</small>", unsafe_allow_html=True)


# ─── Inicializar BD ──────────────────────────────────────────────────────────
db_path = inicializar_db()


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 1 — INICIO / KPIs
# ════════════════════════════════════════════════════════════════════════════
if pagina == "🏠 Inicio / KPIs":
    st.markdown("""
    <div class="titulo-principal">
        <h1>📊 Sistema Contable</h1>
        <p>{nombre_empresa} — Panel de Control Financiero</p>
    </div>
    """, unsafe_allow_html=True)

    resumen = _cargar_resumen()
    total_activos = resumen.get("ACTIVO", 0)
    total_pasivos = abs(resumen.get("PASIVO", 0))
    total_capital = abs(resumen.get("CAPITAL", 0))
    total_ingresos = abs(resumen.get("INGRESO", 0))
    total_gastos = abs(resumen.get("GASTO", 0))
    utilidad = total_ingresos - total_gastos

    # ── KPIs principales ─────────────────────────────────────────────────
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("💰 Total Activos", f"C$ {total_activos:,.0f}",
                  help="Suma de todos los activos del catálogo")
    with col2:
        st.metric("🏦 Total Pasivos", f"C$ {total_pasivos:,.0f}",
                  delta=f"-{(total_pasivos/total_activos*100):.1f}% de activos" if total_activos else None,
                  delta_color="inverse")
    with col3:
        st.metric("🏛️ Capital", f"C$ {total_capital:,.0f}")
    with col4:
        delta_color = "normal" if utilidad >= 0 else "inverse"
        st.metric("📈 Utilidad del Período", f"C$ {utilidad:,.0f}", delta_color=delta_color)

    st.markdown("---")

    # ── Gráficas ─────────────────────────────────────────────────────────
    col_g1, col_g2 = st.columns(2)

    with col_g1:
        st.markdown('<div class="seccion-header">Composición del Balance</div>', unsafe_allow_html=True)
        fig_pie = px.pie(
            values=[total_activos, total_pasivos, total_capital],
            names=["Activos", "Pasivos", "Capital"],
            color_discrete_sequence=["#1976D2", "#E53935", "#43A047"],
            hole=0.45
        )
        fig_pie.update_layout(
            showlegend=True,
            margin=dict(t=10, b=10, l=10, r=10),
            height=300,
        )
        fig_pie.update_traces(textposition="inside", textinfo="percent+label")
        st.plotly_chart(fig_pie, width="stretch")

    with col_g2:
        st.markdown('<div class="seccion-header">Saldos por Tipo de Cuenta</div>', unsafe_allow_html=True)

        # Cargar y agrupar catálogo por tipo
        df_cat = _cargar_catalogo()
        if not df_cat.empty:
            tipo_totales = df_cat.groupby("Tipo")["Saldo Actual (C$)"].sum().reset_index()
            tipo_totales = tipo_totales[tipo_totales["Saldo Actual (C$)"] != 0]
            fig_bar = px.bar(
                tipo_totales,
                x="Tipo",
                y="Saldo Actual (C$)",
                color="Tipo",
                color_discrete_sequence=px.colors.qualitative.Set2,
                text_auto=".2s"
            )
            fig_bar.update_layout(
                showlegend=False,
                margin=dict(t=10, b=10, l=10, r=10),
                height=300,
                yaxis_title="Saldo (C$)",
                xaxis_title="",
            )
            st.plotly_chart(fig_bar, width="stretch")

    # ── Ecuación Contable ────────────────────────────────────────────────
    st.markdown('<div class="seccion-header">Verificación — Ecuación Contable</div>', unsafe_allow_html=True)
    from app.contabilidad.balance import verificar_ecuacion_contable
    ecuacion = verificar_ecuacion_contable()

    col_e1, col_e2, col_e3, col_e4 = st.columns(4)
    with col_e1:
        st.metric("Total Activos", f"C$ {ecuacion['total_activos']:,.2f}")
    with col_e2:
        st.metric("Total Pasivos + Capital", f"C$ {ecuacion['total_pasivos_capital']:,.2f}")
    with col_e3:
        st.metric("Diferencia", f"C$ {ecuacion['diferencia']:,.2f}")
    with col_e4:
        if ecuacion["cuadra"]:
            st.success("✅ Ecuación cuadra")
        else:
            st.error("❌ No cuadra")


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 2 — CATÁLOGO DE CUENTAS
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "📋 Catálogo de Cuentas":
    st.markdown('<div class="titulo-principal"><h1>📋 Catálogo de Cuentas</h1><p>Gestión del plan de cuentas contables</p></div>', unsafe_allow_html=True)

    df = _cargar_catalogo()
    df_completo = _cargar_catalogo_completo()

    if df.empty:
        st.warning("⚠️ No hay cuentas en la base de datos. Ejecuta la migración primero.")
        if st.button("🔄 Ejecutar Migración de Datos"):
            with st.spinner("Migrando datos desde CSV..."):
                from app.base_datos.migrador import ejecutar_migracion
                ejecutar_migracion()
            st.cache_data.clear()
            st.success("✅ Migración completada")
            st.rerun()
    else:
        # Filtros
        col_f1, col_f2, col_f3 = st.columns(3)
        with col_f1:
            busqueda = st.text_input("🔍 Buscar (código o nombre)", placeholder="Ej: 1101, Caja")
        with col_f2:
            tipo_filtro = st.selectbox("Tipo", ["Todos", "ACTIVO", "PASIVO", "CAPITAL", "INGRESO", "GASTO"])
        with col_f3:
            st.metric("Total de cuentas", len(df))

        # Aplicar filtros
        df_filtrado = df.copy()
        if busqueda:
            mask = (
                df_filtrado["Código"].str.contains(busqueda, case=False, na=False) |
                df_filtrado["Nombre"].str.contains(busqueda, case=False, na=False)
            )
            df_filtrado = df_filtrado[mask]
        if tipo_filtro != "Todos":
            df_filtrado = df_filtrado[df_filtrado["Tipo"] == tipo_filtro]

        st.dataframe(
            df_filtrado,
            width="stretch",
            height=450,
            column_config={
                "Saldo Inicial (C$)": st.column_config.NumberColumn(format="C$ %,.2f"),
                "Saldo Actual (C$)": st.column_config.NumberColumn(format="C$ %,.2f"),
            }
        )

        st.markdown("---")
        st.markdown("#### 📥 Cargar catálogo desde Excel")
        st.caption("Descarga la plantilla, completa una fila por cuenta y súbela para revisar los cambios antes de guardarlos.")
        from app.contabilidad.importador_catalogo import (
            crear_plantilla_catalogo,
            importar_catalogo_excel,
            leer_catalogo_excel,
        )
        col_plantilla_catalogo, col_archivo_catalogo = st.columns([1, 2])
        with col_plantilla_catalogo:
            st.download_button(
                "⬇️ Descargar plantilla",
                data=crear_plantilla_catalogo(),
                file_name="plantilla_catalogo_contable.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="descargar_plantilla_catalogo",
                width="stretch",
            )
        with col_archivo_catalogo:
            archivo_catalogo = st.file_uploader(
                "Selecciona el catálogo Excel",
                type=["xlsx"],
                key="archivo_catalogo_excel",
            )

        if archivo_catalogo is not None:
            try:
                archivo_catalogo.seek(0)
                catalogo_preparado = leer_catalogo_excel(archivo_catalogo)
                archivo_catalogo.seek(0)
                st.dataframe(
                    pd.read_excel(archivo_catalogo, engine="openpyxl"),
                    width="stretch",
                    hide_index=True,
                )
                st.info(f"✅ Archivo válido: {len(catalogo_preparado)} cuenta(s) lista(s) para importar.")
                if st.button("💾 Importar catálogo", key="importar_catalogo_excel", width="stretch"):
                    archivo_catalogo.seek(0)
                    resultado_catalogo = importar_catalogo_excel(archivo_catalogo)
                    st.cache_data.clear()
                    st.success(
                        f"✅ Se procesaron {resultado_catalogo['procesadas']} cuenta(s): "
                        f"{resultado_catalogo['creadas']} nueva(s) y "
                        f"{resultado_catalogo['actualizadas']} actualizada(s)."
                    )
                    st.rerun()
            except ValueError as e:
                st.error(f"❌ Catálogo no válido: {e}")
            except Exception as e:
                st.error(f"❌ No se pudo importar el catálogo: {e}")

        st.markdown("---")
        st.markdown("#### Gestionar cuentas")
        from app.contabilidad.catalogo import actualizar_cuenta, crear_cuenta, desactivar_cuenta, eliminar_cuenta, reactivar_cuenta
        tipos_cuenta = ["ACTIVO", "PASIVO", "CAPITAL", "INGRESO", "GASTO", "DESCONOCIDO"]

        tab_agregar, tab_editar, tab_desactivar, tab_reactivar, tab_eliminar = st.tabs(["➕ Agregar", "✏️ Editar", "🚫 Desactivar", "✅ Reactivar", "🗑️ Eliminar"])
        with tab_agregar:
            with st.form("form_agregar_cuenta"):
                col_a1, col_a2 = st.columns(2)
                with col_a1:
                    nuevo_codigo = st.text_input("Código *", key="nuevo_codigo")
                    nuevo_nombre = st.text_input("Nombre de cuenta *", key="nuevo_nombre")
                    nuevo_tipo = st.selectbox("Tipo *", tipos_cuenta, key="nuevo_tipo")
                with col_a2:
                    nueva_clasificacion = st.text_input("Clasificación", key="nueva_clasificacion")
                    nueva_cuenta_padre = st.text_input("Cuenta padre", key="nueva_cuenta_padre")
                    nuevo_saldo = st.number_input("Saldo inicial (C$)", min_value=0.0, value=0.0, step=100.0, key="nuevo_saldo")
                guardar_nueva = st.form_submit_button("➕ Crear cuenta", width="stretch")
            if guardar_nueva:
                if not nuevo_codigo.strip() or not nuevo_nombre.strip():
                    st.error("El código y el nombre son obligatorios.")
                else:
                    try:
                        crear_cuenta(
                            codigo=nuevo_codigo,
                            nombre=nuevo_nombre,
                            clasificacion=nueva_clasificacion,
                            tipo=nuevo_tipo,
                            saldo_inicial=nuevo_saldo,
                            cuenta_padre=nueva_cuenta_padre or None,
                        )
                        st.cache_data.clear()
                        st.success(f"✅ Cuenta {nuevo_codigo} creada correctamente.")
                        st.rerun()
                    except ValueError as e:
                        st.error(f"❌ No se pudo crear: {e}")

        with tab_editar:
            opciones_edicion = {f"{fila['Código']} — {fila['Nombre']}": fila['Código'] for _, fila in df.iterrows()}
            cuenta_editar_label = st.selectbox("Cuenta a editar", list(opciones_edicion), key="cuenta_editar")
            cuenta_editar_codigo = opciones_edicion[cuenta_editar_label]
            datos_edicion = df[df["Código"] == cuenta_editar_codigo].iloc[0]
            with st.form("form_editar_cuenta"):
                col_e1, col_e2 = st.columns(2)
                with col_e1:
                    editar_nombre = st.text_input("Nombre de cuenta *", value=datos_edicion["Nombre"], key="editar_nombre")
                    editar_tipo = st.selectbox("Tipo *", tipos_cuenta, index=tipos_cuenta.index(datos_edicion["Tipo"]) if datos_edicion["Tipo"] in tipos_cuenta else 0, key="editar_tipo")
                with col_e2:
                    editar_clasificacion = st.text_input("Clasificación", value=datos_edicion["Clasificación"], key="editar_clasificacion")
                    editar_padre = st.text_input("Cuenta padre", key="editar_padre")
                guardar_edicion = st.form_submit_button("💾 Guardar cambios", width="stretch")
            if guardar_edicion:
                try:
                    actualizar_cuenta(
                        codigo=cuenta_editar_codigo,
                        nombre=editar_nombre,
                        clasificacion=editar_clasificacion,
                        tipo=editar_tipo,
                        cuenta_padre=editar_padre or None,
                    )
                    st.cache_data.clear()
                    st.success(f"✅ Cuenta {cuenta_editar_codigo} actualizada correctamente.")
                    st.rerun()
                except ValueError as e:
                    st.error(f"❌ No se pudo actualizar: {e}")

        with tab_desactivar:
            cuentas_activas = df_completo[df_completo["Estado"] == "Activa"]
            if cuentas_activas.empty:
                st.info("No hay cuentas activas para desactivar.")
            else:
                opciones_desactivar = {f"{fila['Código']} — {fila['Nombre']}": fila['Código'] for _, fila in cuentas_activas.iterrows()}
                cuenta_desactivar_label = st.selectbox("Cuenta a desactivar", list(opciones_desactivar), key="cuenta_desactivar")
                cuenta_desactivar_codigo = opciones_desactivar[cuenta_desactivar_label]
                st.warning("La cuenta desactivada dejará de aparecer en reportes y no podrá ser utilizada en nuevos asientos ni movimientos.")
                confirmar_desactivacion = st.checkbox("Confirmo que deseo desactivar esta cuenta", key="confirmar_desactivacion")
                if st.button("🚫 Desactivar cuenta", key="desactivar_cuenta", disabled=not confirmar_desactivacion, width="stretch"):
                    try:
                        desactivar_cuenta(cuenta_desactivar_codigo)
                        st.cache_data.clear()
                        st.success(f"✅ Cuenta {cuenta_desactivar_codigo} desactivada correctamente.")
                        st.rerun()
                    except ValueError as e:
                        st.error(f"❌ No se pudo desactivar: {e}")

        with tab_reactivar:
            cuentas_inactivas = df_completo[df_completo["Estado"] == "Inactiva"]
            if cuentas_inactivas.empty:
                st.info("No hay cuentas desactivadas para reactivar.")
            else:
                opciones_reactivar = {f"{fila['Código']} — {fila['Nombre']}": fila['Código'] for _, fila in cuentas_inactivas.iterrows()}
                cuenta_reactivar_label = st.selectbox("Cuenta a reactivar", list(opciones_reactivar), key="cuenta_reactivar")
                cuenta_reactivar_codigo = opciones_reactivar[cuenta_reactivar_label]
                confirmar_activacion = st.checkbox("Confirmo que deseo reactivar esta cuenta", key="confirmar_activacion")
                if st.button("✅ Reactivar cuenta", key="reactivar_cuenta", disabled=not confirmar_activacion, width="stretch"):
                    try:
                        reactivar_cuenta(cuenta_reactivar_codigo)
                        st.cache_data.clear()
                        st.success(f"✅ Cuenta {cuenta_reactivar_codigo} reactivada correctamente.")
                        st.rerun()
                    except ValueError as e:
                        st.error(f"❌ No se pudo reactivar: {e}")

        with tab_eliminar:
            cuenta_eliminar_label = st.selectbox("Cuenta a eliminar", list(opciones_edicion), key="cuenta_eliminar")
            cuenta_eliminar_codigo = opciones_edicion[cuenta_eliminar_label]
            st.warning("Solo se pueden eliminar cuentas con saldo inicial, saldo actual y movimientos en cero.")
            confirmar_eliminacion = st.checkbox("Confirmo que deseo eliminar esta cuenta", key="confirmar_eliminacion")
            if st.button("🗑️ Eliminar cuenta", key="eliminar_cuenta", disabled=not confirmar_eliminacion, width="stretch"):
                try:
                    eliminar_cuenta(cuenta_eliminar_codigo)
                    st.cache_data.clear()
                    st.success(f"✅ Cuenta {cuenta_eliminar_codigo} eliminada correctamente.")
                    st.rerun()
                except ValueError as e:
                    st.error(f"❌ No se pudo eliminar: {e}")

        # Exportar
        st.markdown("---")
        col_x1, col_x2 = st.columns(2)
        with col_x1:
            if st.button("📥 Exportar a Excel"):
                from app.contabilidad.catalogo import obtener_todas
                from app.reportes.exportar import exportar_catalogo_excel
                cuentas = obtener_todas()
                ruta = exportar_catalogo_excel(cuentas)
                st.success(f"✅ Exportado: {ruta}")

        with col_x2:
            # Botón de migración en caso de pocos datos
            if len(df) < 10:
                if st.button("🔄 Re-importar desde CSV"):
                    with st.spinner("Migrando..."):
                        from app.base_datos.migrador import ejecutar_migracion
                        ejecutar_migracion()
                    st.cache_data.clear()
                    st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# DATOS DE LA EMPRESA
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "🏢 Personalizar Empresa":
    st.markdown('<div class="titulo-principal"><h1>🏢 Personalizar Empresa</h1><p>Actualiza el nombre, RUC y dirección de la empresa</p></div>', unsafe_allow_html=True)

    from app.base_datos.empresa import guardar_datos_empresa, obtener_datos_empresa
    datos_empresa = obtener_datos_empresa()

    st.markdown("#### 📌 Datos actuales de la empresa")
    col_info_1, col_info_2, col_info_3 = st.columns(3)
    with col_info_1:
        st.info(f"**Nombre:**\n{datos_empresa['nombre']}")
    with col_info_2:
        st.info(f"**RUC:**\n{datos_empresa['ruc'] or 'No registrado'}")
    with col_info_3:
        st.info(f"**Dirección:**\n{datos_empresa['direccion'] or 'No registrada'}")

    st.markdown("---")
    st.markdown("#### ✏️ Editar información")
    with st.form("form_datos_empresa"):
        nombre_empresa = st.text_input("Nombre de la empresa *", value=datos_empresa["nombre"])
        ruc_empresa = st.text_input("Número RUC", value=datos_empresa["ruc"], placeholder="Ej: J0310000000000")
        direccion_empresa = st.text_area("Dirección", value=datos_empresa["direccion"], placeholder="Dirección fiscal de la empresa")
        guardar_empresa = st.form_submit_button("💾 Guardar datos de empresa", width="stretch")

    if guardar_empresa:
        try:
            guardar_datos_empresa(nombre_empresa, ruc_empresa, direccion_empresa)
            st.cache_data.clear()
            st.success("✅ Datos de empresa guardados correctamente.")
            st.rerun()
        except ValueError as e:
            st.error(f"❌ No se pudieron guardar los datos: {e}")


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 3 — REGISTRAR ASIENTO
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "📝 Registrar Asiento":
    st.markdown('<div class="titulo-principal"><h1>📝 Registrar Asiento Contable</h1><p>Partida doble — DEBE = HABER</p></div>', unsafe_allow_html=True)

    from app.contabilidad.catalogo import obtener_todas
    cuentas = obtener_todas()
    opciones_cuentas = {f"{c.codigo} — {c.nombre}": c.codigo for c in cuentas}

    with st.form("form_asiento"):
        col1, col2 = st.columns(2)
        with col1:
            descripcion = st.text_input("Descripción del asiento *", placeholder="Ej: Pago de nómina enero 2026")
        with col2:
            referencia = st.text_input("Referencia / N° Documento", placeholder="Ej: FAC-001")

        fecha = st.date_input("Fecha del asiento", value=date.today())

        st.markdown("##### Líneas del Asiento")
        st.caption("Agrega al menos 2 líneas. El total DEBE debe ser igual al total HABER.")

        # Crear hasta 6 líneas dinámicas
        lineas_data = []
        num_lineas = st.number_input("Número de líneas", min_value=2, max_value=8, value=2, step=1)

        for i in range(int(num_lineas)):
            col_c, col_d, col_h = st.columns([3, 1, 1])
            with col_c:
                cuenta_sel = st.selectbox(f"Cuenta {i+1}", list(opciones_cuentas.keys()), key=f"cuenta_{i}")
            with col_d:
                debe = st.number_input("DEBE (C$)", min_value=0.0, step=100.0, key=f"debe_{i}", format="%.2f")
            with col_h:
                haber = st.number_input("HABER (C$)", min_value=0.0, step=100.0, key=f"haber_{i}", format="%.2f")
            lineas_data.append((opciones_cuentas[cuenta_sel], debe, haber))

        # Mostrar totales en tiempo real
        total_d = sum(d for _, d, _ in lineas_data)
        total_h = sum(h for _, _, h in lineas_data)
        col_t1, col_t2, col_t3 = st.columns(3)
        with col_t1:
            st.metric("Total DEBE", f"C$ {total_d:,.2f}")
        with col_t2:
            st.metric("Total HABER", f"C$ {total_h:,.2f}")
        with col_t3:
            diff = abs(total_d - total_h)
            if diff < 0.01:
                st.success("✅ Cuadra")
            else:
                st.error(f"❌ Diferencia: C$ {diff:,.2f}")

        submitted = st.form_submit_button("💾 Registrar Asiento", width="stretch")

    if submitted:
        if not descripcion:
            st.error("La descripción es obligatoria.")
        elif abs(total_d - total_h) >= 0.01:
            st.error(f"El asiento no cuadra. Diferencia: C$ {abs(total_d - total_h):,.2f}")
        else:
            lineas_validas = [(c, d, h) for c, d, h in lineas_data if d > 0 or h > 0]
            if len(lineas_validas) < 2:
                st.error("Se necesitan al menos 2 líneas con montos.")
            else:
                try:
                    from app.contabilidad.asientos import registrar_asiento
                    fecha_dt = datetime.combine(fecha, datetime.min.time())
                    asiento = registrar_asiento(
                        descripcion=descripcion,
                        lineas=lineas_validas,
                        fecha=fecha_dt,
                        referencia=referencia or None
                    )
                    st.cache_data.clear()
                    st.success(f"✅ Asiento registrado exitosamente: **{asiento.numero}**")
                    st.balloons()
                except ValueError as e:
                    st.error(f"❌ Error de validación: {e}")
                except Exception as e:
                    st.error(f"❌ Error inesperado: {e}")

    st.markdown("---")
    st.markdown("#### 📥 Cargar asientos desde Excel")
    st.caption("Una fila por línea. Las filas con el mismo ID_ASIENTO se registran como un solo asiento.")
    from app.contabilidad.importador_asientos import (
        crear_plantilla_asientos,
        importar_asientos_excel,
        leer_asientos_excel,
    )

    col_plantilla, col_archivo = st.columns([1, 2])
    with col_plantilla:
        st.download_button(
            "⬇️ Descargar plantilla Excel",
            data=crear_plantilla_asientos(),
            file_name="plantilla_asientos.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="descargar_plantilla_asientos",
            width="stretch",
        )
    with col_archivo:
        archivo_asientos = st.file_uploader(
            "Selecciona el archivo de asientos",
            type=["xlsx"],
            key="archivo_asientos_excel",
        )

    if archivo_asientos is not None:
        try:
            archivo_asientos.seek(0)
            asientos_preparados = leer_asientos_excel(archivo_asientos)
            archivo_asientos.seek(0)
            st.dataframe(
                pd.read_excel(archivo_asientos, engine="openpyxl"),
                width="stretch",
                hide_index=True,
            )
            st.info(f"✅ Excel valido: {len(asientos_preparados)} asiento(s) listo(s) para importar.")
            if st.button("💾 Registrar asientos del Excel", key="registrar_asientos_excel", width="stretch"):
                archivo_asientos.seek(0)
                resultado_importacion = importar_asientos_excel(archivo_asientos)
                st.cache_data.clear()
                st.success(
                    f"✅ Se registraron {resultado_importacion['cantidad']} asiento(s): "
                    + ", ".join(resultado_importacion["numeros"])
                )
        except ValueError as e:
            st.error(f"❌ Excel no valido: {e}")
        except Exception as e:
            st.error(f"❌ No se pudo importar el Excel: {e}")


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 4 — LIBRO DIARIO
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "📚 Libro Diario":
    st.markdown('<div class="titulo-principal"><h1>📚 Libro Diario</h1><p>Registro cronológico de asientos contables</p></div>', unsafe_allow_html=True)

    asientos = _cargar_asientos(limite=100)

    from app.contabilidad.diario import conteo_asientos
    stats = conteo_asientos()

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Asientos", stats["total"])
    with col2:
        st.metric("Manuales", stats["manuales"])
    with col3:
        st.metric("Por OCR", stats["ocr"])
    with col4:
        st.metric("Por IA", stats["ia"])

    if not asientos:
        st.info("ℹ️ No hay asientos registrados aún. Ve a 'Registrar Asiento' para crear el primero.")
    else:
        # Tabla resumen
        rows = []
        for a in asientos:
            rows.append({
                "N° Asiento": a["numero"],
                "Fecha": a["fecha"].strftime("%d/%m/%Y") if a["fecha"] else "—",
                "Descripción": a["descripcion"][:60],
                "Ref.": a["referencia"],
                "Tipo": a["tipo"],
                "Total DEBE (C$)": a["total_debe"],
                "Total HABER (C$)": a["total_haber"],
                "✓": "✅" if a["balanceado"] else "❌",
            })
        df_diario = pd.DataFrame(rows)
        st.dataframe(
            df_diario,
            width="stretch",
            height=350,
            column_config={
                "Total DEBE (C$)": st.column_config.NumberColumn(format="C$ %,.2f"),
                "Total HABER (C$)": st.column_config.NumberColumn(format="C$ %,.2f"),
            }
        )

        # Ver detalle de asiento
        st.markdown("---")
        st.markdown("##### Ver detalle de asiento")
        numeros = [a["numero"] for a in asientos]
        sel = st.selectbox("Selecciona un asiento", numeros)
        asiento_sel = next((a for a in asientos if a["numero"] == sel), None)
        if asiento_sel:
            st.markdown(f"**{asiento_sel['numero']}** — {asiento_sel['descripcion']}")
            st.caption(f"Fecha: {asiento_sel['fecha']} | Ref: {asiento_sel['referencia']} | Tipo: {asiento_sel['tipo']}")
            df_lineas = pd.DataFrame(asiento_sel["lineas"])
            if not df_lineas.empty:
                st.dataframe(
                    df_lineas,
                    width="stretch",
                    column_config={
                        "debe": st.column_config.NumberColumn("DEBE (C$)", format="C$ %,.2f"),
                        "haber": st.column_config.NumberColumn("HABER (C$)", format="C$ %,.2f"),
                    }
                )


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 5 — LIBRO MAYOR / GENERAL LEDGER
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "📖 Libro Mayor / General Ledger":
    st.markdown('<div class="titulo-principal"><h1>📖 Libro Mayor / General Ledger</h1><p>Movimientos y saldo acumulado por cuenta contable</p></div>', unsafe_allow_html=True)

    from app.contabilidad.catalogo import obtener_todas
    from app.contabilidad.mayor import libro_mayor_cuenta

    cuentas = obtener_todas()
    if not cuentas:
        st.info("No hay cuentas contables registradas para consultar el libro mayor.")
    else:
        opciones_cuentas = {
            f"{cuenta.codigo} — {cuenta.nombre}": cuenta.codigo
            for cuenta in cuentas
        }
        cuenta_seleccionada = st.selectbox(
            "Seleccione la cuenta contable",
            list(opciones_cuentas.keys()),
            key="cuenta_libro_mayor",
        )

        col_inicio, col_fin = st.columns(2)
        with col_inicio:
            fecha_inicio_mayor = st.date_input(
                "Desde",
                value=date(date.today().year, 1, 1),
                key="fecha_inicio_libro_mayor",
            )
        with col_fin:
            fecha_fin_mayor = st.date_input(
                "Hasta",
                value=date.today(),
                key="fecha_fin_libro_mayor",
            )

        if fecha_inicio_mayor > fecha_fin_mayor:
            st.error("La fecha inicial no puede ser mayor que la final.")
        else:
            mayor = libro_mayor_cuenta(
                opciones_cuentas[cuenta_seleccionada],
                desde=datetime.combine(fecha_inicio_mayor, datetime.min.time()),
                hasta=datetime.combine(fecha_fin_mayor, datetime.max.time()),
            )
            cuenta = mayor["cuenta"]

            st.markdown(
                f"**{cuenta['codigo']} — {cuenta['nombre']}**  "
                f"\nClasificación: {cuenta['clasificacion'] or '—'} | Tipo: {cuenta['tipo'] or '—'}"
            )
            col_saldo, col_debe, col_haber, col_final = st.columns(4)
            with col_saldo:
                st.metric("Saldo inicial", f"C$ {mayor['saldo_inicial']:,.2f}")
            with col_debe:
                st.metric("Total Debe", f"C$ {mayor['total_debe']:,.2f}")
            with col_haber:
                st.metric("Total Haber", f"C$ {mayor['total_haber']:,.2f}")
            with col_final:
                st.metric("Saldo final", f"C$ {mayor['saldo_final']:,.2f}")

            if mayor["movimientos"]:
                df_mayor = pd.DataFrame(mayor["movimientos"])
                df_mayor["fecha"] = pd.to_datetime(df_mayor["fecha"]).dt.strftime("%d/%m/%Y")
                df_mayor = df_mayor[[
                    "fecha", "numero_asiento", "descripcion", "referencia",
                    "debe", "haber", "saldo"
                ]].rename(columns={
                    "fecha": "Fecha",
                    "numero_asiento": "N° Asiento",
                    "descripcion": "Descripción",
                    "referencia": "Documento",
                    "debe": "Debe",
                    "haber": "Haber",
                    "saldo": "Saldo acumulado",
                })
                st.dataframe(
                    df_mayor,
                    width="stretch",
                    hide_index=True,
                    column_config={
                        "Debe": st.column_config.NumberColumn("Debe (C$)", format="C$ %,.2f"),
                        "Haber": st.column_config.NumberColumn("Haber (C$)", format="C$ %,.2f"),
                        "Saldo acumulado": st.column_config.NumberColumn("Saldo acumulado (C$)", format="C$ %,.2f"),
                    },
                )
            else:
                st.info("No hay movimientos para la cuenta y el rango de fechas seleccionados.")


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 6 — REPORTES FINANCIEROS
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "📈 Reportes Financieros":
    st.markdown(f'<div class="titulo-principal"><h1>📈 Reportes Financieros</h1><p>Estados financieros de {nombre_empresa}</p></div>', unsafe_allow_html=True)

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Balance General",
        "📉 Estado de Resultados",
        "💵 Flujo de Caja",
        "📒 Balanza de Comprobación",
        "🧾 Resumen de Movimientos",
    ])

    with tab1:
        st.markdown("#### Estado de Situación Financiera")
        with st.spinner("Generando Balance General..."):
            from app.reportes.balance_general import generar_balance_general
            balance = generar_balance_general()

        cuadra_text = "✅ Cuadrado" if balance["cuadra"] else f"⚠️ Diferencia: C$ {balance['diferencia']:,.2f}"
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Activos", f"C$ {balance['activos']['total']:,.2f}")
        with col2:
            st.metric("Total Pasivos", f"C$ {balance['pasivos']['total']:,.2f}")
        with col3:
            st.metric("Capital", f"C$ {balance['capital']['total']:,.2f}")

        st.caption(cuadra_text)

        # Activos
        st.markdown("**ACTIVOS**")
        activos_rows = []
        for g in balance["activos"]["grupos"]:
            for c in g["cuentas"]:
                activos_rows.append({"Clasificación": g["clasificacion"], "Código": c["codigo"], "Nombre": c["nombre"], "Saldo (C$)": c["saldo"]})
        if activos_rows:
            st.dataframe(pd.DataFrame(activos_rows), width="stretch",
                         column_config={"Saldo (C$)": st.column_config.NumberColumn(format="C$ %,.2f")})

        # Pasivos
        st.markdown("**PASIVOS**")
        pasivos_rows = []
        for g in balance["pasivos"]["grupos"]:
            for c in g["cuentas"]:
                pasivos_rows.append({"Clasificación": g["clasificacion"], "Código": c["codigo"], "Nombre": c["nombre"], "Saldo (C$)": abs(c["saldo"])})
        if pasivos_rows:
            st.dataframe(pd.DataFrame(pasivos_rows), width="stretch",
                         column_config={"Saldo (C$)": st.column_config.NumberColumn(format="C$ %,.2f")})

        # Capital
        st.markdown("**CAPITAL**")
        capital_rows = []
        for g in balance["capital"]["grupos"]:
            for c in g["cuentas"]:
                capital_rows.append({"Clasificación": g["clasificacion"], "Código": c["codigo"], "Nombre": c["nombre"], "Saldo (C$)": abs(c["saldo"])})
        if capital_rows:
            st.dataframe(pd.DataFrame(capital_rows), width="stretch",
                         column_config={"Saldo (C$)": st.column_config.NumberColumn(format="C$ %,.2f")})

        # Exportar
        if st.button("📥 Exportar Balance a Excel", key="exp_balance"):
            from app.reportes.exportar import exportar_balance_excel
            ruta = exportar_balance_excel(balance)
            st.success(f"✅ Exportado: {ruta}")

    with tab2:
        st.markdown("#### Estado de Rendimiento Acumulado")
        with st.spinner("Generando Estado de Resultados..."):
            from app.reportes.estado_resultados import generar_estado_resultados
            er = generar_estado_resultados()

        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Ingresos", f"C$ {er['ingresos']['total']:,.2f}")
        with col2:
            st.metric("Total Costos + Gastos", f"C$ {er['costos']['total'] + er['gastos_operacion']['total']:,.2f}")
        with col3:
            utilidad = er["utilidad_operativa"]
            st.metric("Utilidad Operativa", f"C$ {utilidad:,.2f}",
                      delta="Ganancia" if utilidad >= 0 else "Pérdida",
                      delta_color="normal" if utilidad >= 0 else "inverse")

        # Gráfica
        labels = ["Ingresos", "Costos", "Gastos de Operación", "Utilidad Operativa"]
        values = [er["ingresos"]["total"], er["costos"]["total"],
                  er["gastos_operacion"]["total"], er["utilidad_operativa"]]
        colors_er = ["#43A047", "#E53935", "#FB8C00", "#1976D2"]

        fig_er = go.Figure(go.Bar(
            x=labels, y=values,
            marker_color=colors_er,
            text=[f"C$ {v:,.0f}" for v in values],
            textposition="outside"
        ))
        fig_er.update_layout(height=300, margin=dict(t=20, b=10), yaxis_title="C$")
        st.plotly_chart(fig_er, width="stretch")

        if st.button("📥 Exportar a Excel", key="exp_er"):
            from app.reportes.exportar import exportar_estado_resultados_excel
            ruta = exportar_estado_resultados_excel(er)
            st.success(f"✅ Exportado: {ruta}")

    with tab3:
        st.markdown("#### Flujo de Efectivo")
        with st.spinner("Generando Flujo de Caja..."):
            from app.reportes.flujo_caja import generar_flujo_caja
            flujo = generar_flujo_caja()

        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Entradas", f"C$ {flujo['total_entradas']:,.2f}")
        with col2:
            st.metric("Total Salidas", f"C$ {flujo['total_salidas']:,.2f}")
        with col3:
            st.metric("Flujo Neto", f"C$ {flujo['flujo_neto']:,.2f}",
                      delta_color="normal" if flujo["flujo_neto"] >= 0 else "inverse")

        if flujo["movimientos"]:
            df_flujo = pd.DataFrame(flujo["movimientos"])
            df_flujo["fecha"] = pd.to_datetime(df_flujo["fecha"]).dt.strftime("%d/%m/%Y")
            st.dataframe(df_flujo, width="stretch",
                         column_config={"monto": st.column_config.NumberColumn("Monto (C$)", format="C$ %,.2f")})
        else:
            st.info("No hay movimientos de efectivo registrados aún.")

    with tab4:
        st.markdown("#### Balanza de Comprobación / Trial Balance")
        with st.spinner("Generando balanza de comprobación..."):
            from app.contabilidad.balance import generar_balance_comprobacion
            balanza = generar_balance_comprobacion()

        st.caption("La balanza muestra el saldo inicial, los movimientos del período (débito y crédito) y el saldo final por cuenta.")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Débito", f"C$ {balanza['total_debe']:,.2f}")
        with col2:
            st.metric("Total Crédito", f"C$ {balanza['total_haber']:,.2f}")
        with col3:
            diff = abs(balanza['total_debe'] - balanza['total_haber'])
            st.metric("Diferencia", f"C$ {diff:,.2f}", delta="Cuadrado" if balanza['balanceado'] else "Descuadre")

        if balanza.get("cuentas"):
            df_balanza = pd.DataFrame(balanza["cuentas"])
            columnas = [
                "codigo", "nombre", "clasificacion", "tipo",
                "saldo_inicial", "total_debe", "total_haber", "saldo_final"
            ]
            for col in columnas:
                if col not in df_balanza.columns:
                    df_balanza[col] = 0.0
            df_balanza = df_balanza[columnas].rename(columns={
                "codigo": "Código",
                "nombre": "Cuenta",
                "clasificacion": "Clasificación",
                "tipo": "Tipo",
                "saldo_inicial": "Saldo inicial",
                "total_debe": "Debe del mes",
                "total_haber": "Haber del mes",
                "saldo_final": "Saldo final"
            })
            st.dataframe(df_balanza, width="stretch",
                         column_config={
                             "Saldo inicial": st.column_config.NumberColumn(format="C$ %,.2f"),
                             "Debe del mes": st.column_config.NumberColumn(format="C$ %,.2f"),
                             "Haber del mes": st.column_config.NumberColumn(format="C$ %,.2f"),
                             "Saldo final": st.column_config.NumberColumn(format="C$ %,.2f")
                         })
        else:
            st.info("No existen cuentas registradas para la balanza de comprobación.")

        if st.button("📥 Exportar Balanza a Excel", key="exp_balanza"):
            from app.reportes.exportar import exportar_balanza_comprobacion_excel
            ruta = exportar_balanza_comprobacion_excel(balanza)
            st.success(f"✅ Exportado: {ruta}")

    with tab5:
        st.markdown("#### Resumen de Movimientos por Fecha")
        st.caption("Consulta el detalle de los movimientos contables dentro de un rango de fechas establecido.")

        from app.contabilidad.diario import resumen_movimientos_por_rango

        col_inicio, col_fin = st.columns(2)
        with col_inicio:
            fecha_inicio = st.date_input("Desde", value=date.today().replace(day=1))
        with col_fin:
            fecha_fin = st.date_input("Hasta", value=date.today())

        if fecha_inicio > fecha_fin:
            st.error("La fecha inicial no puede ser mayor que la final.")
        else:
            desde_dt = datetime.combine(fecha_inicio, datetime.min.time())
            hasta_dt = datetime.combine(fecha_fin, datetime.max.time())

            with st.spinner("Consultando movimientos..."):
                resumen = resumen_movimientos_por_rango(desde=desde_dt, hasta=hasta_dt)

            col_m1, col_m2, col_m3 = st.columns(3)
            with col_m1:
                st.metric("Total Débito", f"C$ {resumen['total_debe']:,.2f}")
            with col_m2:
                st.metric("Total Crédito", f"C$ {resumen['total_haber']:,.2f}")
            with col_m3:
                st.metric("Asientos", resumen["cantidad_asientos"])

            if resumen["movimientos"]:
                df_movimientos = pd.DataFrame(resumen["movimientos"])
                df_movimientos = df_movimientos[[
                    "numero_asiento", "cuenta", "nombre_cuenta", "descripcion",
                    "documentos", "debe", "haber"
                ]].rename(columns={
                    "numero_asiento": "N° Asiento",
                    "cuenta": "Cuenta",
                    "nombre_cuenta": "Nombre de la cuenta",
                    "descripcion": "Descripción",
                    "documentos": "Documentos",
                    "debe": "Debe",
                    "haber": "Haber",
                })
                st.dataframe(
                    df_movimientos,
                    width="stretch",
                    column_config={
                        "Debe": st.column_config.NumberColumn("Debe (C$)", format="C$ %,.2f"),
                        "Haber": st.column_config.NumberColumn("Haber (C$)", format="C$ %,.2f"),
                    }
                )
            else:
                st.info("No hay movimientos registrados para ese rango de fechas.")


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 6 — OCR
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "🔍 OCR — Documentos":
    st.markdown('<div class="titulo-principal"><h1>🔍 OCR — Procesamiento de Documentos</h1><p>Extrae datos de facturas y comprobantes automáticamente</p></div>', unsafe_allow_html=True)

    uploaded = st.file_uploader(
        "Sube una imagen de factura o comprobante",
        type=["jpg", "jpeg", "png", "bmp", "tiff"],
        help="Formatos soportados: JPG, PNG, BMP, TIFF"
    )

    if uploaded is not None:
        col1, col2 = st.columns([1, 1])

        with col1:
            st.markdown("**Vista previa del documento:**")
            st.image(uploaded, width="stretch")

        with col2:
            st.markdown("**Datos extraídos:**")
            with st.spinner("Procesando imagen con OCR..."):
                from app.ocr.extractor import extraer_desde_bytes
                from app.ocr.parser import parsear_documento
                from app.ocr.validador import validar_documento, resumen_validacion

                texto = extraer_desde_bytes(uploaded.read(), uploaded.name)
                datos = parsear_documento(texto)
                validacion = validar_documento(datos)

            if "error" not in datos:
                col_d1, col_d2 = st.columns(2)
                with col_d1:
                    st.metric("Tipo de Documento", datos.get("tipo_documento", "—"))
                    st.metric("Número", datos.get("numero_documento") or "No encontrado")
                with col_d2:
                    monto = datos.get("monto")
                    st.metric("Monto", f"C$ {monto:,.2f}" if monto else "No encontrado")
                    st.metric("Fecha", datos.get("fecha") or "No encontrada")

                st.markdown(f"**Proveedor:** {datos.get('proveedor', 'No identificado')}")
                st.progress(datos.get("confianza_pct", 0) / 100,
                            text=f"Confianza de extracción: {datos.get('confianza_pct', 0)}%")

                # Validación
                st.markdown("---")
                st.text(resumen_validacion(validacion))

                # Texto extraído
                with st.expander("📄 Ver texto completo extraído"):
                    st.text(texto)

                # Sugerir asiento con IA
                if st.button("🤖 Sugerir Asiento con IA"):
                    from app.modelos.asistente import clasificar_transaccion_ocr
                    from app.contabilidad.catalogo import obtener_todas
                    cuentas_list = [{"codigo": c.codigo, "nombre": c.nombre}
                                    for c in obtener_todas()[:30]]
                    with st.spinner("Consultando IA..."):
                        sugerencia = clasificar_transaccion_ocr(texto, cuentas_list)
                    if "error" not in sugerencia:
                        st.success(f"💡 Asiento sugerido: {sugerencia.get('descripcion', '')}")
                        if "lineas" in sugerencia:
                            st.json(sugerencia["lineas"])
                    else:
                        st.warning(f"IA no disponible: {sugerencia.get('error', '')}")
            else:
                st.error(f"Error al procesar: {datos['error']}")
    else:
        st.info("📁 Sube una imagen para comenzar el procesamiento OCR.")
        st.markdown("""
        **¿Qué se puede procesar?**
        - 📄 Facturas de proveedores
        - 🧾 Comprobantes de pago
        - 🏦 Notas bancarias
        - 📋 Recibos de gastos
        """)


# ════════════════════════════════════════════════════════════════════════════
# PÁGINA 7 — ASISTENTE IA
# ════════════════════════════════════════════════════════════════════════════
elif pagina == "🤖 Asistente IA":
    st.markdown('<div class="titulo-principal"><h1>🤖 Asistente Contable IA</h1><p>Powered by Ollama / Gemma — Consultas financieras en lenguaje natural</p></div>', unsafe_allow_html=True)

    # Estado del modelo
    from app.modelos.asistente import OLLAMA_MODEL, OLLAMA_DISPONIBLE

    col_s1, col_s2 = st.columns([3, 1])
    with col_s1:
        st.info(f"🤖 Modelo activo: **{OLLAMA_MODEL}**")
    with col_s2:
        if st.button("🔍 Verificar conexión"):
            from app.modelos.asistente import verificar_conexion
            if verificar_conexion():
                st.success("✅ Conectado")
            else:
                st.error("❌ Sin conexión")

    # Historial del chat
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "llm_history" not in st.session_state:
        st.session_state.llm_history = []

    # Mostrar mensajes
    for msg in st.session_state.chat_history:
        if msg["role"] == "user":
            st.markdown(f'<div class="chat-user">👤 {msg["content"]}</div>', unsafe_allow_html=True)
        else:
            st.markdown(f'<div class="chat-bot">🤖 {msg["content"]}</div>', unsafe_allow_html=True)

    # Sugerencias de preguntas
    if not st.session_state.chat_history:
        st.markdown("**💡 Preguntas de ejemplo:**")
        sugerencias = [
            "¿Cuál es el total de activos de la empresa?",
            "¿Qué cuentas de efectivo existen?",
            "¿Cuál es el capital social de la empresa?",
            "¿Cuántas cuentas de gastos hay registradas?",
        ]
        cols = st.columns(2)
        for i, sug in enumerate(sugerencias):
            with cols[i % 2]:
                if st.button(f"💬 {sug}", key=f"sug_{i}"):
                    st.session_state.pending_question = sug

    # Input de pregunta
    pregunta = st.chat_input("Escribe tu pregunta contable...")

    # Procesar pregunta (de input o sugerencia)
    if pregunta or st.session_state.get("pending_question"):
        q = pregunta or st.session_state.pop("pending_question", "")
        if q:
            st.session_state.chat_history.append({"role": "user", "content": q})

            with st.spinner("🤔 Pensando..."):
                resumen = _cargar_resumen()
                from app.modelos.asistente import preguntar
                respuesta = preguntar(
                    q,
                    contexto_financiero=resumen,
                    historial=st.session_state.llm_history
                )

            st.session_state.chat_history.append({"role": "assistant", "content": respuesta})
            st.session_state.llm_history.append({"role": "user", "content": q})
            st.session_state.llm_history.append({"role": "assistant", "content": respuesta})
            st.rerun()

    # Limpiar chat
    if st.session_state.chat_history:
        if st.button("🗑️ Limpiar conversación"):
            st.session_state.chat_history = []
            st.session_state.llm_history = []
            st.rerun()
