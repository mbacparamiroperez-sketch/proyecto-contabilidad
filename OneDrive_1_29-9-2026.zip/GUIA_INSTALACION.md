# Guia de instalacion y actualizacion

## Sistema Contable

Esta guia explica como instalar la version actual del Sistema Contable en una laptop o PC con Windows. El instalador valida que la copia incluya las funciones actuales del dashboard antes de continuar.

## 1. Requisitos

- Windows 10 u 11 de 64 bits.
- Python 3.10 o superior instalado desde https://www.python.org/downloads/windows/
- Durante la instalacion de Python, activar la opcion **Add Python to PATH**.
- Conexion a Internet durante la primera instalacion para descargar las dependencias.
- Permisos de escritura en la carpeta donde se instalara el sistema.

Python, Tesseract y Ollama son componentes distintos:

- Python es obligatorio para ejecutar el sistema.
- Tesseract OCR es opcional y se necesita para leer facturas e imagenes.
- Ollama/Gemma es opcional y se necesita para el asistente IA.

## 2. Copiar la version completa

1. Copia la carpeta completa `sistema_contable` al equipo destino.
2. No copies la carpeta `venv` desde otro equipo. Si existe y no es compatible, el instalador la recreara.
3. Conserva estas rutas y archivos:
   - `dashboard.py`
   - `requirements.txt`
   - `app\`
   - `instalar_sistema.bat`
   - `instalar_sistema.ps1`
   - `iniciar_sistema.ps1`

No es necesario copiar archivos temporales como `__pycache__`.

## 3. Instalacion automatica

1. Abre la carpeta del sistema.
2. Haz doble clic en `instalar_sistema.bat`.
3. Espera a que aparezca **Instalacion completada**.
4. El instalador realiza estas tareas:
   - valida que la copia este completa;
   - crea o reconstruye el entorno virtual de Python;
   - instala las dependencias de `requirements.txt`;
   - valida Streamlit, SQLAlchemy, pandas, Excel, reportes, OCR y Ollama;
   - crea `.env` usando `p.env` si no existe;
   - crea las tablas SQLite;
   - carga el catalogo inicial si la base de datos aun no existe;
   - crea el acceso directo **Sistema Contable** en el escritorio.

Como alternativa, abre PowerShell en la carpeta del proyecto y ejecuta:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\instalar_sistema.ps1
```

## 4. Iniciar el sistema

Usa el acceso directo del escritorio o ejecuta:

```powershell
.\iniciar_sistema.ps1
```

El navegador se abrira en `http://127.0.0.1:8501`. Si el puerto esta ocupado, el launcher buscara automaticamente el siguiente puerto disponible.

El sistema funciona localmente en el equipo. Para abrirlo desde otro equipo de la misma red, usa la direccion de red que muestra Streamlit y permite el acceso en el Firewall de Windows solo si es necesario.

El acceso directo inicia Streamlit como un proceso independiente de la ventana de PowerShell. Puedes cerrar la ventana de PowerShell sin detener el sistema.

## 5. Salir de forma segura

En la barra lateral selecciona **🚪 Salir del sistema** y confirma con **Cerrar**. Esto cierra la sesion de la interfaz sin apagar abruptamente Streamlit ni borrar datos. Luego puedes cerrar la pestaña del navegador.

El servidor local puede continuar ejecutandose para permitir otra sesion. Para detenerlo completamente, cierra el proceso de Streamlit desde la ventana donde fue iniciado o finaliza el proceso de Python correspondiente.

## 6. Funciones de la version actual

- **📖 Libro Mayor / General Ledger:** consulta movimientos y saldo acumulado por cuenta y rango de fechas.
- **🧾 Resumen de Movimientos:** consulta numero de asiento, cuenta, nombre de cuenta, descripcion, documento, debe y haber.
- **📈 Reportes Financieros:** balance general, estado de resultados, flujo de caja y balanza de comprobacion.
- **📋 Catalogo de Cuentas:** alta, edicion, desactivacion, reactivacion e importacion desde Excel.

## 7. Actualizar a una version nueva

1. Cierra el sistema antes de copiar la nueva version.
2. Realiza una copia de seguridad de:
   - `app\base_datos\contable.db`
   - `documentos\`
   - `.env`
3. Copia los archivos de la version nueva sobre la carpeta del sistema.
4. Ejecuta `instalar_sistema.bat` nuevamente.
5. El instalador actualizara las dependencias y conservara la base de datos existente.
6. Inicia el sistema desde el acceso directo.

No borres `contable.db` durante una actualizacion: contiene las cuentas, asientos y configuracion de empresa.

## 8. Configuracion de empresa

La empresa, RUC y direccion se editan desde:

**Personalizar Empresa**

Los datos se guardan en SQLite y se utilizan en los reportes financieros y exportaciones.

## 9. OCR opcional

Para procesar facturas e imagenes, instala Tesseract OCR desde:

https://github.com/UB-Mannheim/tesseract/wiki

Ruta recomendada:

```text
C:\Program Files\Tesseract-OCR\tesseract.exe
```

Si la instalacion usa otra ruta, configura `TESSERACT_CMD` en `.env`.

## 10. Asistente IA opcional

1. Instala Ollama desde https://ollama.com/download
2. Descarga el modelo configurado:

```powershell
ollama pull gemma4:e4b
```

3. Verifica en `.env`:

```env
OLLAMA_HOST=http://localhost:11434
OLLAMA_MODEL=gemma4:e4b
```

El resto del sistema funciona aunque Ollama no este instalado.

## 11. Problemas frecuentes

### Python no se encuentra

Instala Python desde la pagina oficial y activa **Add Python to PATH**. Cierra y vuelve a abrir PowerShell, y ejecuta el instalador otra vez.

### El instalador indica que falta un archivo

La copia esta incompleta. Vuelve a copiar la carpeta completa del proyecto, incluyendo `app`, `dashboard.py` y `requirements.txt`.

### El navegador muestra Connection error

Confirma que el host este activo y abre `http://127.0.0.1:8501`. Si no responde, ejecuta `iniciar_sistema.ps1` desde la carpeta del proyecto.

### El puerto 8501 esta ocupado

Usa `iniciar_sistema.ps1`; seleccionara otro puerto disponible automaticamente.

### El navegador no abre

Abre manualmente la URL que muestra la ventana de PowerShell, por ejemplo `http://localhost:8501`.

### No aparecen las cuentas iniciales

Confirma que exista `app\base_datos\catalogo_saldos iniciales.csv`. Si la base de datos fue creada vacia, ejecuta:

```powershell
.\venv\Scripts\python.exe app\base_datos\migrador.py
```

### No funciona OCR

Instala Tesseract OCR y confirma la ruta del ejecutable. OCR no es necesario para registrar asientos manualmente.

## 12. Desinstalacion

1. Cierra el sistema.
2. Guarda una copia de `app\base_datos\contable.db` y `documentos\` si deseas conservar la informacion.
3. Elimina la carpeta del proyecto.
4. Elimina manualmente el acceso directo del escritorio.

El instalador no modifica el registro de Windows ni instala servicios permanentes.
