# Instala el Sistema Contable para uso local en Windows.
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot
$VenvPath = Join-Path $ProjectRoot "venv"
$PythonExe = Join-Path $VenvPath "Scripts\python.exe"
$RequirementsPath = Join-Path $ProjectRoot "requirements.txt"
$DatabasePath = Join-Path $ProjectRoot "app\base_datos\contable.db"
$DatabaseWasPresent = Test-Path $DatabasePath
$RequiredPaths = @(
    (Join-Path $ProjectRoot "dashboard.py"),
    (Join-Path $ProjectRoot "app"),
    $RequirementsPath
)
$FeatureMarkers = @(
    "Libro Mayor / General Ledger",
    "Resumen de Movimientos",
    "Salir del sistema"
)

function Find-Python {
    if (Get-Command py -ErrorAction SilentlyContinue) {
        return "py"
    }
    if (Get-Command python -ErrorAction SilentlyContinue) {
        return "python"
    }
    throw "Python 3 no esta instalado. Descargalo desde https://www.python.org/downloads/windows/"
}

function Invoke-Checked {
    param(
        [string]$FilePath,
        [string[]]$Arguments
    )
    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "El comando fallo ($LASTEXITCODE): $FilePath $($Arguments -join ' ')"
    }
}

foreach ($RequiredPath in $RequiredPaths) {
    if (-not (Test-Path $RequiredPath)) {
        throw "Falta un archivo o carpeta requerida: $RequiredPath. Copia la version completa del sistema."
    }
}
foreach ($FeatureMarker in $FeatureMarkers) {
    if (-not (Select-String -Path (Join-Path $ProjectRoot "dashboard.py") -Pattern $FeatureMarker -SimpleMatch)) {
        throw "La copia no contiene la funcionalidad actual requerida: $FeatureMarker. Usa la version mas reciente."
    }
}

$VenvValido = $false
if (Test-Path $PythonExe) {
    & $PythonExe -c "import sys; print(sys.executable)" *> $null
    $VenvValido = ($LASTEXITCODE -eq 0)
}

if (-not $VenvValido) {
    if (Test-Path $VenvPath) {
        Write-Host "El entorno virtual no es valido para este equipo. Recreandolo..." -ForegroundColor Yellow
        Remove-Item -Recurse -Force $VenvPath
    }
    $Python = Find-Python
    Write-Host "Creando entorno virtual..." -ForegroundColor Cyan
    if ($Python -eq "py") {
        Invoke-Checked "py" @("-3", "-m", "venv", $VenvPath)
    } else {
        Invoke-Checked "python" @("-m", "venv", $VenvPath)
    }
}

Write-Host "Instalando dependencias..." -ForegroundColor Cyan
Invoke-Checked $PythonExe @("-m", "pip", "install", "--upgrade", "pip")
Invoke-Checked $PythonExe @("-m", "pip", "install", "-r", $RequirementsPath)
Write-Host "Validando dependencias de la version actual..." -ForegroundColor Cyan
Invoke-Checked $PythonExe @(
    "-c",
    "import pandas, openpyxl, plotly, reportlab, sqlalchemy, streamlit, pytesseract, ollama"
)

$EnvPath = Join-Path $ProjectRoot ".env"
$EnvTemplatePath = Join-Path $ProjectRoot "p.env"
if ((-not (Test-Path $EnvPath)) -and (Test-Path $EnvTemplatePath)) {
    Copy-Item $EnvTemplatePath $EnvPath
    Write-Host "Configuracion inicial creada en .env" -ForegroundColor Cyan
}

Write-Host "Inicializando la base de datos..." -ForegroundColor Cyan
Invoke-Checked $PythonExe @("-c", "from app.base_datos.database import crear_tablas; crear_tablas()")
$CatalogPath = Join-Path $ProjectRoot "app\base_datos\catalogo_saldos iniciales.csv"
if ((-not $DatabaseWasPresent) -and (Test-Path $CatalogPath)) {
    Invoke-Checked $PythonExe @("app\base_datos\migrador.py")
}

$LauncherPath = Join-Path $ProjectRoot "iniciar_sistema.ps1"
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $DesktopPath "Sistema Contable.lnk"
$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = "powershell.exe"
$Shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$LauncherPath`""
$Shortcut.WorkingDirectory = $ProjectRoot
$Shortcut.Description = "Iniciar Sistema Contable en localhost"
$Shortcut.Save()

Write-Host "Instalacion completada." -ForegroundColor Green
Write-Host "Acceso directo creado en: $ShortcutPath"
Write-Host "Puedes iniciar el sistema con iniciar_sistema.ps1 o desde el acceso directo."
