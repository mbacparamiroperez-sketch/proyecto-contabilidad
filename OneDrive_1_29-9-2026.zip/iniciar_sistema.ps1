# Inicia el Sistema Contable en localhost.
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot
$PythonExe = Join-Path $ProjectRoot "venv\Scripts\python.exe"

if (-not (Test-Path $PythonExe)) {
    Write-Host "El sistema no esta instalado. Ejecuta instalar_sistema.ps1 primero." -ForegroundColor Yellow
    Read-Host "Presiona Enter para cerrar"
    exit 1
}

$Port = 8501
$PuertoOcupado = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($PuertoOcupado) {
    try {
        $Respuesta = Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$Port" -TimeoutSec 3
        if ($Respuesta.StatusCode -eq 200) {
            Write-Host "El sistema ya esta ejecutandose en http://localhost:$Port" -ForegroundColor Green
            Start-Process "http://localhost:$Port"
            exit 0
        }
    } catch {
        # El puerto esta ocupado por otro proceso; se busca el siguiente.
    }
    do {
        $Port++
        $PuertoOcupado = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
    } while ($PuertoOcupado)
}

$Url = "http://127.0.0.1:$Port"
Write-Host "Iniciando Sistema Contable en $Url ..." -ForegroundColor Green
$ArgumentList = @(
    "-m", "streamlit", "run", "dashboard.py",
    "--server.port", $Port,
    "--server.address", "127.0.0.1",
    "--server.headless", "true"
)
$Proceso = Start-Process -FilePath $PythonExe -ArgumentList $ArgumentList -WorkingDirectory $ProjectRoot -PassThru

$Listo = $false
for ($Intento = 0; $Intento -lt 30; $Intento++) {
    Start-Sleep -Milliseconds 500
    try {
        $Respuesta = Invoke-WebRequest -UseBasicParsing -Uri $Url -TimeoutSec 2
        if ($Respuesta.StatusCode -eq 200) {
            $Listo = $true
            break
        }
    } catch {
        if ($Proceso.HasExited) {
            break
        }
    }
}

if ($Listo) {
    Start-Process $Url
} else {
    Write-Host "No fue posible iniciar el sistema. Revise la ventana de Streamlit o ejecute instalar_sistema.ps1 nuevamente." -ForegroundColor Red
    if (-not $Proceso.HasExited) {
        Stop-Process -Id $Proceso.Id -Force -ErrorAction SilentlyContinue
    }
    Read-Host "Presiona Enter para cerrar"
    exit 1
}
