from app.base_datos.database import SessionLocal, CuentaContable

session = SessionLocal()
cuentas = session.query(CuentaContable).all()

activos = sum(c.saldo_inicial for c in cuentas if c.tipo == 'ACTIVO')
pasivos = sum(c.saldo_inicial for c in cuentas if c.tipo == 'PASIVO')
capital = sum(c.saldo_inicial for c in cuentas if c.tipo == 'CAPITAL')

print(f"Total Activos: {activos:,.2f}")
print(f"Total Pasivos: {pasivos:,.2f}")
print(f"Total Capital: {capital:,.2f}")
print(f"Suma Pasivo + Capital: {(pasivos + capital):,.2f}")

# Look for accounts with "Test" in name or code 9999, 8001, etc.
test_accounts = [c for c in cuentas if 'test' in c.nombre.lower() or c.codigo in ('9999', '8001', '8002', '8003')]
if test_accounts:
    print("\nCuentas de prueba encontradas:")
    for c in test_accounts:
        print(f"{c.codigo} - {c.nombre} (Tipo: {c.tipo}): {c.saldo_inicial:,.2f}")

session.close()
