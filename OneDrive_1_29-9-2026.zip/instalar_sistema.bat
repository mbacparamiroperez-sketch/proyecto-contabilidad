@echo off
setlocal
PowerShell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar_sistema.ps1"
if errorlevel 1 (
	echo.
	echo La instalacion no se completo. Revisa el mensaje anterior.
	pause
	exit /b 1
)
echo.
echo La instalacion termino correctamente.
pause
