"""
test_catalogo.py — Pruebas del Módulo de Catálogo de Cuentas
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.base_datos.database import crear_tablas, SessionLocal, CuentaContable


def setup():
    """Crear tablas antes de los tests."""
    crear_tablas()


def test_crear_cuenta():
    """Verifica que se puede crear una cuenta."""
    from app.contabilidad.catalogo import crear_cuenta, obtener_por_codigo, desactivar_cuenta

    codigo_test = "9999"
    # Limpiar si existe
    session = SessionLocal()
    existente = session.query(CuentaContable).filter_by(codigo=codigo_test).first()
    if existente:
        session.delete(existente)
        session.commit()
    session.close()

    cuenta = crear_cuenta(
        codigo=codigo_test,
        nombre="Cuenta de Prueba",
        tipo="ACTIVO",
        saldo_inicial=1000.0
    )
    assert cuenta.codigo == codigo_test
    assert cuenta.nombre == "Cuenta de Prueba"
    assert cuenta.saldo_inicial == 1000.0
    assert cuenta.activa is True
    print(f"  ✅ test_crear_cuenta: {cuenta}")

    # Limpiar
    desactivar_cuenta(codigo_test)


def test_buscar_cuenta():
    """Verifica la búsqueda de cuentas."""
    from app.contabilidad.catalogo import buscar

    resultados = buscar("Caja")
    # Solo verificamos que no falla; puede estar vacío si no hay datos
    assert isinstance(resultados, list)
    print(f"  ✅ test_buscar_cuenta: {len(resultados)} resultado(s)")


def test_resumen_por_tipo():
    """Verifica que el resumen por tipo retorna un dict."""
    from app.contabilidad.catalogo import resumen_por_tipo

    resumen = resumen_por_tipo()
    assert isinstance(resumen, dict)
    print(f"  ✅ test_resumen_por_tipo: {resumen}")


def test_obtener_todas():
    """Verifica que se puede obtener la lista completa."""
    from app.contabilidad.catalogo import obtener_todas

    cuentas = obtener_todas()
    assert isinstance(cuentas, list)
    print(f"  ✅ test_obtener_todas: {len(cuentas)} cuentas")


def test_actualizar_y_eliminar_cuenta_sin_saldo():
    """Verifica edición y eliminación de una cuenta sin saldo ni movimientos."""
    from app.contabilidad.catalogo import actualizar_cuenta, crear_cuenta, eliminar_cuenta, obtener_por_codigo

    codigo_test = "9998"
    session = SessionLocal()
    existente = session.query(CuentaContable).filter_by(codigo=codigo_test).first()
    if existente:
        session.delete(existente)
        session.commit()
    session.close()

    crear_cuenta(codigo_test, "Cuenta temporal", tipo="ACTIVO")
    cuenta = actualizar_cuenta(codigo_test, "Cuenta editada", tipo="PASIVO")
    assert cuenta.nombre == "Cuenta editada"
    assert cuenta.tipo == "PASIVO"
    assert eliminar_cuenta(codigo_test) is True
    assert obtener_por_codigo(codigo_test) is None
    print("  ✅ test_actualizar_y_eliminar_cuenta_sin_saldo: OK")


def test_no_eliminar_cuenta_con_saldo():
    """Verifica que una cuenta con saldo no pueda eliminarse."""
    from app.contabilidad.catalogo import crear_cuenta, eliminar_cuenta

    codigo_test = "9997"
    session = SessionLocal()
    existente = session.query(CuentaContable).filter_by(codigo=codigo_test).first()
    if existente:
        session.delete(existente)
        session.commit()
    session.close()

    crear_cuenta(codigo_test, "Cuenta con saldo", tipo="ACTIVO", saldo_inicial=100.0)
    try:
        eliminar_cuenta(codigo_test)
        assert False, "Una cuenta con saldo no debe eliminarse"
    except ValueError as error:
        assert "saldo" in str(error).lower()
    finally:
        session = SessionLocal()
        cuenta = session.query(CuentaContable).filter_by(codigo=codigo_test).first()
        if cuenta:
            session.delete(cuenta)
            session.commit()
        session.close()
    print("  ✅ test_no_eliminar_cuenta_con_saldo: OK")


if __name__ == "__main__":
    print("=" * 50)
    print("  TESTS — Módulo Catálogo de Cuentas")
    print("=" * 50)
    setup()
    test_crear_cuenta()
    test_buscar_cuenta()
    test_resumen_por_tipo()
    test_obtener_todas()
    print("\n✅ Todos los tests pasaron.")
