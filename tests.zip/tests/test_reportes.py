"""
test_reportes.py — Pruebas de los Módulos de Reportes
"""

import sys
import tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from openpyxl import load_workbook

from app.base_datos.database import crear_tablas


def setup():
    crear_tablas()


def test_balance_general_estructura():
    """Verifica que el balance general retorna la estructura correcta."""
    from app.reportes.balance_general import generar_balance_general

    balance = generar_balance_general()
    assert "empresa" in balance
    assert "activos" in balance
    assert "pasivos" in balance
    assert "capital" in balance
    assert "total_pasivos_capital" in balance
    print(f"  ✅ test_balance_general_estructura: OK")
    print(f"     Activos: C$ {balance['activos']['total']:,.2f}")
    print(f"     Pasivos: C$ {balance['pasivos']['total']:,.2f}")


def test_exportacion_balance_incluye_cuentas_capital():
    """Verifica que el Excel del balance incluya el detalle de capital."""
    from app.reportes.balance_general import generar_balance_general
    from app.reportes.exportar import exportar_balance_excel

    balance = generar_balance_general()
    with tempfile.TemporaryDirectory() as directorio:
        ruta = Path(directorio) / "balance.xlsx"
        exportar_balance_excel(balance, str(ruta))
        hoja = load_workbook(ruta, data_only=True).active
        valores = [
            hoja.cell(fila, columna).value
            for fila in range(1, hoja.max_row + 1)
            for columna in (1, 4)
        ]

    assert "CAPITAL" in valores
    assert "TOTAL PASIVO + CAPITAL" in valores
    assert any(str(valor).strip().startswith("30000 —") for valor in valores)


def test_estado_resultados_estructura():
    """Verifica que el estado de resultados retorna la estructura correcta."""
    from app.reportes.estado_resultados import generar_estado_resultados

    er = generar_estado_resultados()
    assert "ingresos" in er
    assert "costos" in er
    assert "gastos_operacion" in er
    assert "utilidad_bruta" in er
    assert "utilidad_operativa" in er
    print(f"  ✅ test_estado_resultados_estructura: OK")
    print(f"     Ingresos: C$ {er['ingresos']['total']:,.2f}")


def test_balance_comprobacion():
    """Verifica el balance de comprobación."""
    from app.contabilidad.balance import generar_balance_comprobacion

    bc = generar_balance_comprobacion()
    assert "cuentas" in bc
    assert "total_debe" in bc
    assert "total_haber" in bc
    assert "balanceado" in bc
    print(f"  ✅ test_balance_comprobacion: {len(bc['cuentas'])} cuentas")


def test_exportacion_balanza_comprobacion_excel():
    """Verifica que la balanza pueda exportarse a Excel con saldos iniciales y finales."""
    from app.contabilidad.balance import generar_balance_comprobacion
    from app.reportes.exportar import exportar_balanza_comprobacion_excel

    bc = generar_balance_comprobacion()
    with tempfile.TemporaryDirectory() as directorio:
        ruta = Path(directorio) / "balanza_comprobacion.xlsx"
        exportar_balanza_comprobacion_excel(bc, str(ruta))
        hoja = load_workbook(ruta, data_only=True).active
        valores = [hoja.cell(fila, 1).value for fila in range(1, hoja.max_row + 1)]

    assert any(str(valor).strip() == "SALDO INICIAL" for valor in valores)
    assert any(str(valor).strip() == "SALDO FINAL" for valor in valores)
    assert "TOTAL DÉBITO" in valores or "TOTAL DEBE" in valores


def test_ecuacion_contable():
    """Verifica la ecuación contable A = P + C."""
    from app.contabilidad.balance import verificar_ecuacion_contable

    ec = verificar_ecuacion_contable()
    assert "total_activos" in ec
    assert "total_pasivos_capital" in ec
    assert "cuadra" in ec
    print(f"  ✅ test_ecuacion_contable:")
    print(f"     Activos: C$ {ec['total_activos']:,.2f}")
    print(f"     Pasivos+Capital: C$ {ec['total_pasivos_capital']:,.2f}")
    print(f"     Cuadra: {ec['cuadra']}")


def test_flujo_caja():
    """Verifica la estructura del flujo de caja."""
    from app.reportes.flujo_caja import generar_flujo_caja

    flujo = generar_flujo_caja()
    assert "total_entradas" in flujo
    assert "total_salidas" in flujo
    assert "flujo_neto" in flujo
    print(f"  ✅ test_flujo_caja:")
    print(f"     Entradas: C$ {flujo['total_entradas']:,.2f}")
    print(f"     Salidas:  C$ {flujo['total_salidas']:,.2f}")


def test_resumen_movimientos_rango_fechas():
    """Verifica que el resumen por rango de fechas devuelve movimientos y totales."""
    from datetime import datetime, timedelta
    from app.contabilidad.diario import resumen_movimientos_por_rango

    desde = datetime.today() - timedelta(days=30)
    hasta = datetime.today() + timedelta(days=1)
    resumen = resumen_movimientos_por_rango(desde=desde, hasta=hasta)

    assert "movimientos" in resumen
    assert "total_debe" in resumen
    assert "total_haber" in resumen
    assert "cantidad_asientos" in resumen
    assert isinstance(resumen["movimientos"], list)


if __name__ == "__main__":
    print("=" * 50)
    print("  TESTS — Módulo Reportes Financieros")
    print("=" * 50)
    setup()
    test_balance_general_estructura()
    test_estado_resultados_estructura()
    test_balance_comprobacion()
    test_ecuacion_contable()
    test_flujo_caja()
    print("\n✅ Todos los tests pasaron.")
