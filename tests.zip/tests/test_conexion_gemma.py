"""
test_conexion_gemma.py — Prueba de conexión con Ollama/Gemma
"""

import sys
import os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from dotenv import load_dotenv
load_dotenv()


def test_ollama_disponible():
    """Verifica que el paquete ollama está instalado."""
    try:
        import ollama
        print("  ✅ test_ollama_disponible: Paquete 'ollama' instalado.")
        return True
    except ImportError:
        print("  ❌ test_ollama_disponible: 'ollama' no instalado. Ejecuta: pip install ollama")
        return False


def test_variables_entorno():
    """Verifica que las variables de entorno están configuradas."""
    host = os.getenv("OLLAMA_HOST")
    model = os.getenv("OLLAMA_MODEL")

    assert host is not None, "OLLAMA_HOST no configurado en .env"
    assert model is not None, "OLLAMA_MODEL no configurado en .env"
    print(f"  ✅ test_variables_entorno:")
    print(f"     OLLAMA_HOST={host}")
    print(f"     OLLAMA_MODEL={model}")


def test_conexion_ollama():
    """Intenta conectar con Ollama y verificar respuesta."""
    try:
        import ollama
        modelo = os.getenv("OLLAMA_MODEL", "gemma4:e4b")
        respuesta = ollama.chat(
            model=modelo,
            messages=[{"role": "user", "content": "Di solo: CONEXIÓN OK"}]
        )
        contenido = respuesta["message"]["content"]
        print(f"  ✅ test_conexion_ollama:")
        print(f"     Modelo: {modelo}")
        print(f"     Respuesta: {contenido[:100]}")
    except Exception as e:
        print(f"  ⚠️ test_conexion_ollama: No conectado — {e}")
        print("     (Asegúrate de que Ollama esté en ejecución: ollama serve)")


if __name__ == "__main__":
    print("=" * 50)
    print("  TESTS — Conexión con Ollama/Gemma")
    print("=" * 50)
    if test_ollama_disponible():
        test_variables_entorno()
        test_conexion_ollama()
    print("\n✅ Tests completados.")
