"""
test_asientos.py — Pruebas del Módulo de Asientos Contables
Verifica la validación de partida doble.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.base_datos.database import crear_tablas, SessionLocal, CuentaContable


def setup():
    """Preparar cuentas de prueba."""
    crear_tablas()
    session = SessionLocal()

    cuentas_prueba = [
        ("8001", "Caja Test", "ACTIVO", 5000.0),
        ("8002", "Capital Test", "CAPITAL", 5000.0),
        ("8003", "Gastos Test", "GASTO", 0.0),
    ]

    for codigo, nombre, tipo, saldo in cuentas_prueba:
        existente = session.query(CuentaContable).filter_by(codigo=codigo).first()
        if not existente:
            cuenta = CuentaContable(
                codigo=codigo, nombre=nombre, tipo=tipo,
                saldo_inicial=saldo, saldo_actual=saldo, activa=True
            )
            session.add(cuenta)

    session.commit()
    session.close()


def teardown():
    """Eliminar cuentas y asientos de prueba."""
    from app.base_datos.database import LineaAsiento, Asiento
    session = SessionLocal()
    # Primero borrar lineas que referencian estas cuentas
    for codigo in ["8001", "8002", "8003"]:
        session.query(LineaAsiento).filter_by(cuenta_codigo=codigo).delete()
    session.commit()
    # Luego borrar asientos de prueba (los que tienen solo esas cuentas)
    # Finalmente borrar las cuentas
    for codigo in ["8001", "8002", "8003"]:
        c = session.query(CuentaContable).filter_by(codigo=codigo).first()
        if c:
            session.delete(c)
    session.commit()
    session.close()


def test_asiento_balanceado():
    """Verifica que un asiento con D=H se registra correctamente."""
    from app.contabilidad.asientos import registrar_asiento

    asiento = registrar_asiento(
        descripcion="Asiento de prueba balanceado",
        lineas=[
            ("8001", 1000.0, 0.0),   # DEBE
            ("8002", 0.0, 1000.0),   # HABER
        ]
    )
    assert asiento.balanceado is True
    assert asiento.total_debe == 1000.0
    assert asiento.total_haber == 1000.0
    print(f"  ✅ test_asiento_balanceado: {asiento.numero}")


def test_asiento_no_balanceado_lanza_error():
    """Verifica que un asiento desbalanceado lanza ValueError."""
    from app.contabilidad.asientos import registrar_asiento

    error_lanzado = False
    try:
        registrar_asiento(
            descripcion="Asiento desbalanceado (debe fallar)",
            lineas=[
                ("8001", 1000.0, 0.0),
                ("8002", 0.0, 500.0),  # Solo 500, debería ser 1000
            ]
        )
    except ValueError:
        error_lanzado = True

    assert error_lanzado, "Debería haber lanzado ValueError"
    print("  ✅ test_asiento_no_balanceado_lanza_error: Error lanzado correctamente")


def test_asiento_cuenta_inexistente():
    """Verifica que usar una cuenta inexistente lanza error."""
    from app.contabilidad.asientos import registrar_asiento

    error_lanzado = False
    try:
        registrar_asiento(
            descripcion="Cuenta inexistente",
            lineas=[
                ("XXXX", 100.0, 0.0),
                ("8002", 0.0, 100.0),
            ]
        )
    except ValueError:
        error_lanzado = True

    assert error_lanzado, "Debería haber lanzado ValueError para cuenta inexistente"
    print("  ✅ test_asiento_cuenta_inexistente: Error lanzado correctamente")


def test_listar_asientos():
    """Verifica que se puede listar asientos."""
    from app.contabilidad.asientos import listar_asientos

    asientos = listar_asientos(limite=10)
    assert isinstance(asientos, list)
    print(f"  ✅ test_listar_asientos: {len(asientos)} asiento(s)")


if __name__ == "__main__":
    print("=" * 50)
    print("  TESTS — Módulo Asientos Contables")
    print("=" * 50)
    setup()
    try:
        test_asiento_balanceado()
        test_asiento_no_balanceado_lanza_error()
        test_asiento_cuenta_inexistente()
        test_listar_asientos()
        print("\n✅ Todos los tests pasaron.")
    finally:
        teardown()
