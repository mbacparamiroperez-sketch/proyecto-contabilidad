"""
flujo_caja.py — Reporte de Flujo de Efectivo
Mueve de cuentas de efectivo en el período.
"""

from datetime import datetime
from sqlalchemy.orm import Session

from app.base_datos.database import CuentaContable, LineaAsiento, Asiento, get_session
from app.base_datos.empresa import obtener_datos_empresa


CLASIFICACIONES_EFECTIVO = [
    "EFECTIVO Y EQUIVALENTE AL EFECTIVO",
    "CAJA",
    "BANCOS",
]


def generar_flujo_caja(desde: datetime = None, hasta: datetime = None, session: Session = None) -> dict:
    """
    Genera el reporte de Flujo de Efectivo para un período.

    Returns:
        Dict con movimientos de efectivo, entradas, salidas y saldo neto.
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        cuentas_efectivo = []
        for clasificacion in CLASIFICACIONES_EFECTIVO:
            cuentas = (
                session.query(CuentaContable)
                .filter(
                    CuentaContable.activa == True,
                    CuentaContable.clasificacion.ilike(f"%{clasificacion}%")
                )
                .all()
            )
            cuentas_efectivo.extend(cuentas)

        movimientos = []
        total_entradas = 0.0
        total_salidas = 0.0

        for cuenta in cuentas_efectivo:
            q = (
                session.query(LineaAsiento)
                .filter_by(cuenta_codigo=cuenta.codigo)
                .join(Asiento)
            )
            if desde:
                q = q.filter(Asiento.fecha >= desde)
            if hasta:
                q = q.filter(Asiento.fecha <= hasta)

            lineas = q.all()
            for l in lineas:
                tipo = "ENTRADA" if l.debe > 0 else "SALIDA"
                monto = l.debe if l.debe > 0 else l.haber
                if tipo == "ENTRADA":
                    total_entradas += monto
                else:
                    total_salidas += monto
                movimientos.append({
                    "fecha": l.asiento.fecha,
                    "asiento": l.asiento.numero,
                    "descripcion": l.asiento.descripcion,
                    "cuenta": cuenta.codigo,
                    "cuenta_nombre": cuenta.nombre,
                    "tipo": tipo,
                    "monto": round(monto, 2),
                })

        movimientos.sort(key=lambda x: x["fecha"])
        empresa = obtener_datos_empresa(session)

        return {
            "empresa": empresa["nombre"],
            "ruc": empresa["ruc"],
            "direccion": empresa["direccion"],
            "titulo": "ESTADO DE FLUJO DE EFECTIVO",
            "desde": desde,
            "hasta": hasta,
            "movimientos": movimientos,
            "total_entradas": round(total_entradas, 2),
            "total_salidas": round(total_salidas, 2),
            "flujo_neto": round(total_entradas - total_salidas, 2),
        }
    finally:
        if close:
            session.close()
