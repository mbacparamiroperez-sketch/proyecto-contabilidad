"""
balance_general.py — Estado de Situación Financiera (Balance General)
Genera el Balance General desde la base de datos.
"""

from datetime import datetime
from typing import Optional
from sqlalchemy.orm import Session

from app.base_datos.database import CuentaContable, get_session
from app.base_datos.empresa import obtener_datos_empresa
from app.contabilidad.balance import verificar_ecuacion_contable


def _cuentas_por_clasificacion(tipo: str, session: Session) -> list:
    """Agrupa cuentas por clasificación para una sección del balance."""
    cuentas = (
        session.query(CuentaContable)
        .filter_by(tipo=tipo, activa=True)
        .order_by(CuentaContable.codigo)
        .all()
    )
    grupos = {}
    for c in cuentas:
        cls = (c.clasificacion or "SIN CLASIFICAR").strip().upper()
        if cls not in grupos:
            grupos[cls] = {"clasificacion": cls, "cuentas": [], "subtotal": 0.0}
        grupos[cls]["cuentas"].append({
            "codigo": c.codigo,
            "nombre": c.nombre,
            "saldo": c.saldo_actual
        })
        grupos[cls]["subtotal"] += c.saldo_actual
        
    # Round subtotals at the end and make sure they are positive for presentation
    for g in grupos.values():
        g["subtotal"] = round(g["subtotal"], 2)
        
    return list(grupos.values())


def generar_balance_general(session: Session = None) -> dict:
    """
    Genera el Estado de Situación Financiera.

    Returns:
        Dict estructurado como el balance: activos, pasivos, capital, totales.
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        activos = _cuentas_por_clasificacion("ACTIVO", session)
        pasivos = _cuentas_por_clasificacion("PASIVO", session)
        capital = _cuentas_por_clasificacion("CAPITAL", session)

        total_activos = round(sum(g["subtotal"] for g in activos), 2)
        total_pasivos = abs(round(sum(g["subtotal"] for g in pasivos), 2))
        total_capital = abs(round(sum(g["subtotal"] for g in capital), 2))

        # Ingresos y Gastos (para calcular utilidad del período)
        ingresos = sum(
            c.saldo_actual
            for c in session.query(CuentaContable).filter_by(tipo="INGRESO", activa=True).all()
        )
        gastos = sum(
            c.saldo_actual
            for c in session.query(CuentaContable).filter_by(tipo="GASTO", activa=True).all()
        )
        utilidad_periodo = round(ingresos - gastos, 2)

        total_pasivos_capital = round(total_pasivos + total_capital + utilidad_periodo, 2)

        # Verificación
        ecuacion = verificar_ecuacion_contable(session)
        empresa = obtener_datos_empresa(session)

        return {
            "empresa": empresa["nombre"],
            "ruc": empresa["ruc"],
            "direccion": empresa["direccion"],
            "titulo": "ESTADO DE SITUACIÓN FINANCIERA",
            "fecha": datetime.utcnow(),
            "activos": {
                "grupos": activos,
                "total": total_activos
            },
            "pasivos": {
                "grupos": pasivos,
                "total": total_pasivos
            },
            "capital": {
                "grupos": capital,
                "total": total_capital,
                "utilidad_periodo": utilidad_periodo,
                "total_con_utilidad": round(total_capital + utilidad_periodo, 2)
            },
            "total_pasivos_capital": total_pasivos_capital,
            "cuadra": ecuacion["cuadra"],
            "diferencia": ecuacion["diferencia"],
        }
    finally:
        if close:
            session.close()
