# Módulo reportes — Generación de estados financieros
