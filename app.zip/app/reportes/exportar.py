"""
exportar.py — Exportación de Reportes a Excel y PDF
Usa openpyxl para Excel y reportlab para PDF.
"""

from datetime import datetime
from pathlib import Path
from typing import Optional

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.enums import TA_CENTER, TA_RIGHT


# ─── Configuración de estilos ────────────────────────────────────────────────

VERDE_OSCURO = "1B5E20"
AZUL_OSCURO = "0D47A1"
GRIS_CLARO = "F5F5F5"
VERDE_CLARO = "E8F5E9"


def _estilo_encabezado(ws, fila: int, color_hex: str = AZUL_OSCURO):
    """Aplica estilo de encabezado a una fila completa."""
    for cell in ws[fila]:
        if cell.value is not None:
            cell.font = Font(bold=True, color="FFFFFF", size=10)
            cell.fill = PatternFill("solid", fgColor=color_hex)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _borde_delgado():
    lado = Side(border_style="thin", color="BDBDBD")
    return Border(left=lado, right=lado, top=lado, bottom=lado)


# ─── Exportar Catálogo de Cuentas a Excel ────────────────────────────────────

def exportar_catalogo_excel(cuentas: list, ruta_salida: str = None) -> str:
    """
    Exporta el catálogo de cuentas a Excel con formato profesional.

    Args:
        cuentas: Lista de CuentaContable (ORM objects).
        ruta_salida: Ruta del archivo Excel (default: auto-generada).

    Returns:
        Ruta del archivo generado.
    """
    if ruta_salida is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        ruta_salida = f"documentos/catalogo_cuentas_{ts}.xlsx"

    Path(ruta_salida).parent.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Catálogo de Cuentas"

    # Título
    ws.merge_cells("A1:G1")
    ws["A1"] = "REPASTADORA DEL SUR, S.A. — CATÁLOGO DE CUENTAS"
    ws["A1"].font = Font(bold=True, size=14, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=AZUL_OSCURO)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws.row_dimensions[1].height = 30

    ws.merge_cells("A2:G2")
    ws["A2"] = f"Generado: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
    ws["A2"].alignment = Alignment(horizontal="center")
    ws["A2"].font = Font(italic=True, color="757575")

    # Encabezados
    headers = ["Código", "Nombre de Cuenta", "Clasificación", "Tipo", "Saldo Inicial (C$)", "Saldo Actual (C$)", "Estado"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=3, column=col, value=h)
    _estilo_encabezado(ws, 3)
    ws.row_dimensions[3].height = 20

    # Datos
    for i, cuenta in enumerate(cuentas, 4):
        es_par = (i % 2 == 0)
        fondo = GRIS_CLARO if es_par else "FFFFFF"

        row_data = [
            getattr(cuenta, 'codigo', ''),
            getattr(cuenta, 'nombre', ''),
            getattr(cuenta, 'clasificacion', ''),
            getattr(cuenta, 'tipo', ''),
            getattr(cuenta, 'saldo_inicial', 0.0),
            getattr(cuenta, 'saldo_actual', 0.0),
            "Activa" if getattr(cuenta, 'activa', True) else "Inactiva"
        ]

        for col, val in enumerate(row_data, 1):
            cell = ws.cell(row=i, column=col, value=val)
            cell.fill = PatternFill("solid", fgColor=fondo)
            cell.border = _borde_delgado()
            if col in (5, 6):
                cell.number_format = '#,##0.00'
                cell.alignment = Alignment(horizontal="right")

    # Ajustar anchos
    widths = [12, 40, 35, 12, 18, 18, 10]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    wb.save(ruta_salida)
    return ruta_salida


# ─── Exportar Balance General a Excel ────────────────────────────────────────

def exportar_balance_excel(balance: dict, ruta_salida: str = None) -> str:
    """Exporta el Balance General en forma de cuenta (presentación horizontal)."""
    if ruta_salida is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        ruta_salida = f"documentos/balance_general_{ts}.xlsx"

    Path(ruta_salida).parent.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Balance General"

    # Encabezado
    encabezado = [balance.get("empresa", "")]
    if balance.get("ruc"):
        encabezado.append(f"RUC: {balance['ruc']}")
    if balance.get("direccion"):
        encabezado.append(balance["direccion"])
    encabezado.extend([
        balance.get("titulo", "ESTADO DE SITUACIÓN FINANCIERA"),
        f"AL {datetime.now().strftime('%d DE %B %Y').upper()}",
        "EN CÓRDOBAS",
    ])
    for fila, texto in enumerate(encabezado, 1):
        ws.merge_cells(f"A{fila}:E{fila}")
        ws[f"A{fila}"] = texto
        ws[f"A{fila}"].alignment = Alignment(horizontal="center")
        if fila == 1:
            ws[f"A{fila}"].font = Font(bold=True, size=13)

    ws.cell(row=6, column=1, value="ACTIVO").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=6, column=1).fill = PatternFill("solid", fgColor=AZUL_OSCURO)
    ws.cell(row=6, column=2, value="VALOR").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=6, column=2).fill = PatternFill("solid", fgColor=AZUL_OSCURO)
    ws.cell(row=6, column=4, value="PASIVO Y CAPITAL").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=6, column=4).fill = PatternFill("solid", fgColor=AZUL_OSCURO)
    ws.cell(row=6, column=5, value="VALOR").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=6, column=5).fill = PatternFill("solid", fgColor=AZUL_OSCURO)

    def escribir_grupos(fila, grupos, columna, columna_valor, signo_positivo=True):
        for grupo in grupos:
            subtotal = grupo["subtotal"] if signo_positivo else abs(grupo["subtotal"])
            ws.cell(row=fila, column=columna, value=f"  {grupo['clasificacion']}").font = Font(bold=True)
            ws.cell(row=fila, column=columna_valor, value=subtotal).number_format = '#,##0.00'
            fila += 1
            for cuenta in grupo.get("cuentas", []):
                saldo = cuenta["saldo"] if signo_positivo else abs(cuenta["saldo"])
                ws.cell(row=fila, column=columna, value=f"    {cuenta['codigo']} — {cuenta['nombre']}")
                ws.cell(row=fila, column=columna_valor, value=saldo).number_format = '#,##0.00'
                fila += 1
        return fila

    fila_activo = escribir_grupos(
        7, balance.get("activos", {}).get("grupos", []), 1, 2
    )
    ws.cell(row=fila_activo, column=1, value="TOTAL ACTIVO").font = Font(bold=True)
    ws.cell(row=fila_activo, column=2, value=balance.get("activos", {}).get("total", 0)).font = Font(bold=True)
    ws.cell(row=fila_activo, column=2).number_format = '#,##0.00'

    fila_pasivo = escribir_grupos(
        7, balance.get("pasivos", {}).get("grupos", []), 4, 5, signo_positivo=False
    )
    ws.cell(row=fila_pasivo, column=4, value="TOTAL PASIVO").font = Font(bold=True)
    ws.cell(row=fila_pasivo, column=5, value=balance.get("pasivos", {}).get("total", 0)).font = Font(bold=True)
    ws.cell(row=fila_pasivo, column=5).number_format = '#,##0.00'
    fila_pasivo += 2
    ws.cell(row=fila_pasivo, column=4, value="CAPITAL").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=fila_pasivo, column=4).fill = PatternFill("solid", fgColor=AZUL_OSCURO)
    fila_pasivo += 1
    fila_pasivo = escribir_grupos(
        fila_pasivo, balance.get("capital", {}).get("grupos", []), 4, 5, signo_positivo=False
    )
    utilidad = balance.get("capital", {}).get("utilidad_periodo", 0)
    ws.cell(row=fila_pasivo, column=4, value="  UTILIDAD DEL PERIODO")
    ws.cell(row=fila_pasivo, column=5, value=utilidad).number_format = '#,##0.00'
    fila_pasivo += 1
    total_pasivo_capital = balance.get("total_pasivos_capital", 0)
    ws.cell(row=fila_pasivo, column=4, value="TOTAL PASIVO + CAPITAL").font = Font(bold=True)
    ws.cell(row=fila_pasivo, column=5, value=total_pasivo_capital).font = Font(bold=True)
    ws.cell(row=fila_pasivo, column=5).number_format = '#,##0.00'

    fila_final = max(fila_activo, fila_pasivo) + 2
    ws.cell(row=fila_final, column=1, value="COMPROBACION: ACTIVO = PASIVO + CAPITAL").font = Font(bold=True)
    ws.cell(row=fila_final, column=2, value=balance.get("cuadra", False) and "CUADRA" or "NO CUADRA")
    ws.cell(row=fila_final, column=4, value="DIFERENCIA").font = Font(bold=True)
    ws.cell(row=fila_final, column=5, value=balance.get("diferencia", 0)).number_format = '#,##0.00'

    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 3
    ws.column_dimensions["D"].width = 48
    ws.column_dimensions["E"].width = 18
    wb.save(ruta_salida)
    return ruta_salida


# ─── Exportar Estado de Resultados a Excel ───────────────────────────────────

def exportar_balanza_comprobacion_excel(balanza: dict, ruta_salida: str = None) -> str:
    """Exporta la balanza de comprobación con saldo inicial, movimientos y saldo final."""
    if ruta_salida is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        ruta_salida = f"documentos/balanza_comprobacion_{ts}.xlsx"

    Path(ruta_salida).parent.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Balanza de Comprobación"

    empresa = balanza.get("empresa", "") or "REPASTADORA DEL SUR, S.A."
    ws.merge_cells("A1:H1")
    ws["A1"] = f"{empresa}"
    ws["A1"].font = Font(bold=True, size=13)
    ws["A1"].alignment = Alignment(horizontal="center")
    ws["A1"].fill = PatternFill("solid", fgColor=AZUL_OSCURO)
    ws["A1"].font = Font(color="FFFFFF", bold=True)

    ws.merge_cells("A2:H2")
    ws["A2"] = "BALANZA DE COMPROBACIÓN / TRIAL BALANCE"
    ws["A2"].font = Font(bold=True)
    ws["A2"].alignment = Alignment(horizontal="center")

    headers = ["Código", "Cuenta", "Clasificación", "Tipo", "Saldo inicial", "Debe del mes", "Haber del mes", "Saldo final"]
    for col, valor in enumerate(headers, 1):
        ws.cell(row=4, column=col, value=valor)
    _estilo_encabezado(ws, 4, AZUL_OSCURO)

    fila = 5
    for cuenta in balanza.get("cuentas", []):
        valores = [
            cuenta.get("codigo", ""),
            cuenta.get("nombre", ""),
            cuenta.get("clasificacion", ""),
            cuenta.get("tipo", ""),
            float(cuenta.get("saldo_inicial", 0.0) or 0.0),
            float(cuenta.get("total_debe", 0.0) or 0.0),
            float(cuenta.get("total_haber", 0.0) or 0.0),
            float(cuenta.get("saldo_final", 0.0) or 0.0),
        ]
        for col, valor in enumerate(valores, 1):
            celda = ws.cell(row=fila, column=col, value=valor)
            celda.border = _borde_delgado()
            if col >= 5:
                celda.number_format = '#,##0.00'
                celda.alignment = Alignment(horizontal="right")
        fila += 1

    total_inicial = round(sum(float(c.get("saldo_inicial", 0.0) or 0.0) for c in balanza.get("cuentas", [])), 2)
    total_debe = round(sum(float(c.get("total_debe", 0.0) or 0.0) for c in balanza.get("cuentas", [])), 2)
    total_haber = round(sum(float(c.get("total_haber", 0.0) or 0.0) for c in balanza.get("cuentas", [])), 2)
    total_final = round(sum(float(c.get("saldo_final", 0.0) or 0.0) for c in balanza.get("cuentas", [])), 2)

    ws.cell(row=fila, column=1, value="TOTAL")
    ws.cell(row=fila, column=1).font = Font(bold=True)
    ws.cell(row=fila, column=5, value=total_inicial).number_format = '#,##0.00'
    ws.cell(row=fila, column=6, value=total_debe).number_format = '#,##0.00'
    ws.cell(row=fila, column=7, value=total_haber).number_format = '#,##0.00'
    ws.cell(row=fila, column=8, value=total_final).number_format = '#,##0.00'
    for col in range(1, 9):
        ws.cell(row=fila, column=col).font = Font(bold=True)
        ws.cell(row=fila, column=col).border = _borde_delgado()

    ws.cell(row=fila + 2, column=1, value="BALANCEADO")
    ws.cell(row=fila + 2, column=2, value="SI" if balanza.get("balanceado", False) else "NO")
    ws.cell(row=fila + 2, column=4, value="DIFERENCIA")
    ws.cell(row=fila + 2, column=5, value=float(balanza.get("diferencia", 0.0) or 0.0)).number_format = '#,##0.00'

    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 38
    ws.column_dimensions["C"].width = 18
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 18
    ws.column_dimensions["F"].width = 18
    ws.column_dimensions["G"].width = 18
    ws.column_dimensions["H"].width = 18

    wb.save(ruta_salida)
    return ruta_salida


def exportar_estado_resultados_excel(reporte: dict, ruta_salida: str = None) -> str:
    """Exporta el Estado de Resultados a Excel."""
    if ruta_salida is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        ruta_salida = f"documentos/estado_resultados_{ts}.xlsx"

    Path(ruta_salida).parent.mkdir(parents=True, exist_ok=True)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Estado de Resultados"

    encabezados = [reporte.get("empresa", "")]
    if reporte.get("ruc"):
        encabezados.append(f"RUC: {reporte['ruc']}")
    if reporte.get("direccion"):
        encabezados.append(reporte["direccion"])
    encabezados.extend([
        reporte.get("titulo", "ESTADO DE RENDIMIENTO"),
        "EN CÓRDOBAS",
    ])
    for i, texto in enumerate(encabezados, 1):
        ws.merge_cells(f"A{i}:C{i}")
        ws[f"A{i}"] = texto
        ws[f"A{i}"].alignment = Alignment(horizontal="center")
        if i == 1:
            ws[f"A{i}"].font = Font(bold=True, size=13)

    fila = 5
    secciones = [
        ("INGRESOS", reporte.get("ingresos", {})),
        ("COSTOS DE VENTAS", reporte.get("costos", {})),
        ("GASTOS DE OPERACIÓN", reporte.get("gastos_operacion", {})),
    ]

    for titulo, datos in secciones:
        ws.cell(row=fila, column=1, value=titulo).font = Font(bold=True, color="FFFFFF")
        ws.cell(row=fila, column=1).fill = PatternFill("solid", fgColor=AZUL_OSCURO)
        fila += 1
        for item in datos.get("detalle", []):
            ws.cell(row=fila, column=1, value=f"  {item['nombre']}")
            cell = ws.cell(row=fila, column=2, value=item["monto"])
            cell.number_format = '#,##0.00'
            fila += 1
        ws.cell(row=fila, column=1, value=f"Total {titulo}").font = Font(bold=True)
        cell = ws.cell(row=fila, column=2, value=datos.get("total", 0))
        cell.font = Font(bold=True)
        cell.number_format = '#,##0.00'
        fila += 2

    # Utilidades
    for label, valor in [
        ("UTILIDAD BRUTA", reporte.get("utilidad_bruta", 0)),
        ("UTILIDAD OPERATIVA", reporte.get("utilidad_operativa", 0)),
    ]:
        ws.cell(row=fila, column=1, value=label).font = Font(bold=True, size=11)
        cell = ws.cell(row=fila, column=2, value=valor)
        cell.font = Font(bold=True, size=11)
        cell.number_format = '#,##0.00'
        fila += 1

    ws.column_dimensions["A"].width = 45
    ws.column_dimensions["B"].width = 20
    wb.save(ruta_salida)
    return ruta_salida
