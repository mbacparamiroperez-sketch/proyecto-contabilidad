"""
estado_resultados.py — Estado de Resultados (Estado de Rendimiento)
Genera el Estado de Resultados desde la base de datos.
"""

from datetime import datetime
from typing import Optional
from sqlalchemy.orm import Session

from app.base_datos.database import CuentaContable, LineaAsiento, Asiento, get_session
from app.base_datos.empresa import obtener_datos_empresa


GRUPOS_ESTADO_RESULTADOS = {
    "INGRESOS": ["INGRESO"],
    "COSTOS": ["COSTOS DE VENTAS", "COSTO"],
    "GASTOS_OPERACION": ["GASTO"],
}


def _saldo_tipo(tipo: str, desde: datetime, hasta: datetime, session: Session) -> float:
    """Calcula el saldo total de cuentas de un tipo en un período."""
    cuentas = (
        session.query(CuentaContable)
        .filter_by(tipo=tipo, activa=True)
        .all()
    )
    total = 0.0
    for cuenta in cuentas:
        q = (
            session.query(LineaAsiento)
            .filter_by(cuenta_codigo=cuenta.codigo)
            .join(Asiento)
        )
        if desde:
            q = q.filter(Asiento.fecha >= desde)
        if hasta:
            q = q.filter(Asiento.fecha <= hasta)
        movs = q.all()
        movimiento = sum(l.haber - l.debe for l in movs)  # Ingresos: haber > debe
        total += movimiento
    return round(total, 2)


def generar_estado_resultados(
    desde: datetime = None,
    hasta: datetime = None,
    session: Session = None
) -> dict:
    """
    Genera el Estado de Resultados para un período dado.

    Returns:
        Dict con secciones de ingresos, costos, gastos, utilidades.
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        # Usar saldos iniciales si no hay período especificado
        cuentas = (
            session.query(CuentaContable)
            .filter_by(activa=True)
            .all()
        )

        ingresos_detalle = []
        costos_detalle = []
        gastos_detalle = []

        for cuenta in cuentas:
            if cuenta.tipo not in ("INGRESO", "GASTO"):
                continue

            # Calcular movimiento del período
            q = session.query(LineaAsiento).filter_by(cuenta_codigo=cuenta.codigo).join(Asiento)
            if desde:
                q = q.filter(Asiento.fecha >= desde)
            if hasta:
                q = q.filter(Asiento.fecha <= hasta)
            movs = q.all()

            if cuenta.tipo == "INGRESO":
                monto = round(cuenta.saldo_inicial + sum(l.haber - l.debe for l in movs), 2)
                if monto != 0:
                    ingresos_detalle.append({
                        "codigo": cuenta.codigo,
                        "nombre": cuenta.nombre,
                        "clasificacion": cuenta.clasificacion,
                        "monto": monto
                    })
            elif cuenta.tipo == "GASTO":
                monto = round(cuenta.saldo_inicial + sum(l.debe - l.haber for l in movs), 2)
                cls_upper = (cuenta.clasificacion or "").upper()
                if "COSTO" in cls_upper or "VENTA" in cls_upper:
                    if monto != 0:
                        costos_detalle.append({
                            "codigo": cuenta.codigo,
                            "nombre": cuenta.nombre,
                            "clasificacion": cuenta.clasificacion,
                            "monto": monto
                        })
                else:
                    if monto != 0:
                        gastos_detalle.append({
                            "codigo": cuenta.codigo,
                            "nombre": cuenta.nombre,
                            "clasificacion": cuenta.clasificacion,
                            "monto": monto
                        })

        total_ingresos = round(sum(i["monto"] for i in ingresos_detalle), 2)
        total_costos = round(sum(c["monto"] for c in costos_detalle), 2)
        utilidad_bruta = round(total_ingresos - total_costos, 2)
        total_gastos = round(sum(g["monto"] for g in gastos_detalle), 2)
        utilidad_operativa = round(utilidad_bruta - total_gastos, 2)
        empresa = obtener_datos_empresa(session)

        return {
            "empresa": empresa["nombre"],
            "ruc": empresa["ruc"],
            "direccion": empresa["direccion"],
            "titulo": "ESTADO DE RENDIMIENTO",
            "desde": desde,
            "hasta": hasta,
            "ingresos": {
                "detalle": sorted(ingresos_detalle, key=lambda x: x["codigo"]),
                "total": total_ingresos
            },
            "costos": {
                "detalle": sorted(costos_detalle, key=lambda x: x["codigo"]),
                "total": total_costos
            },
            "utilidad_bruta": utilidad_bruta,
            "gastos_operacion": {
                "detalle": sorted(gastos_detalle, key=lambda x: x["codigo"]),
                "total": total_gastos
            },
            "utilidad_operativa": utilidad_operativa,
        }
    finally:
        if close:
            session.close()
