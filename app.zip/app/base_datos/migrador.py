"""
migrador.py — Migración de CSV a SQLite
Lee los archivos CSV del catálogo y los importa a la base de datos SQLite.
"""

import re
import sys
import os
from pathlib import Path
from datetime import datetime

import pandas as pd

# Ajustar path para imports
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from app.base_datos.database import (
    crear_tablas, get_session,
    CuentaContable, Periodo
)

# ─── Rutas de archivos ───────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
CATALOGO_CSV = BASE_DIR / "catalogo_saldos iniciales.csv"


# ─── Clasificación → Tipo de cuenta ─────────────────────────────────────────
CLASIFICACION_TIPO = {
    "EFECTIVO Y EQUIVALENTE AL EFECTIVO": "ACTIVO",
    "OTRAS CUENTAS POR COBRAR": "ACTIVO",
    "INVENTARIOS": "ACTIVO",
    "GASTOS ANTICIPADOS": "ACTIVO",
    "IMPUESTOS ANTICIPADOS": "ACTIVO",
    "INVERSIONES": "ACTIVO",
    "TANGIBLE  DEPRECIABLE": "ACTIVO",
    "TANGIBLE NO DEPRECIABLE": "ACTIVO",
    "DEPRECIACION ACUMULADA": "ACTIVO",
    "GASTOS ACUM POR PAGAR": "PASIVO",
    "IMPUESTOS POR PAGAR": "PASIVO",
    "RETENCIONES POR PAGAR": "PASIVO",
    "OTRAS CUENTAS POR PAGAR": "PASIVO",
    "GANADO NACIDO": "PASIVO",
    "CAPITAL SOCIAL": "CAPITAL",
    "UTILIDAD/PERDIDA ACUMULADA": "CAPITAL",
    "UTILIDAD DEL PERIODO": "CAPITAL",
    "INGRESOS": "INGRESO",
    "VENTAS": "INGRESO",
    "COSTOS DE VENTAS": "GASTO",
    "GASTOS DE OPERACION": "GASTO",
    "GASTOS DE GANADERIA": "GASTO",
    "GASTOS DE ADMON": "GASTO",
    "GASTOS DE EQUIPOS": "GASTO",
    "GASTOS TRANSADO POR BOLSA": "GASTO",
    "OTROS GASTOS": "GASTO",
    "OTROS INGRESOS": "INGRESO",
}


def limpiar_codigo(raw: str) -> str:
    """Extrae el código numérico de strings como '110101 — Caja Chica'."""
    if not raw or not isinstance(raw, str):
        return ""
    # Buscar patrón numérico al inicio
    match = re.match(r"^(\d+)", raw.strip())
    return match.group(1) if match else raw.strip()[:20]


def limpiar_nombre(raw: str) -> str:
    """Extrae el nombre de strings como '110101 — Caja Chica'."""
    if not raw or not isinstance(raw, str):
        return raw
    # Remover el código inicial y separadores
    limpio = re.sub(r"^\d+\s*[–\-\?]\s*", "", raw.strip())
    return limpio.strip()[:200]


def determinar_tipo(clasificacion: str) -> str:
    """Determina el tipo de cuenta (ACTIVO/PASIVO/etc.) por la clasificación."""
    if not clasificacion:
        return "DESCONOCIDO"
    clasificacion_upper = str(clasificacion).strip().upper()
    # Búsqueda directa
    if clasificacion_upper in CLASIFICACION_TIPO:
        return CLASIFICACION_TIPO[clasificacion_upper]
    # Búsqueda parcial
    for key, tipo in CLASIFICACION_TIPO.items():
        if key in clasificacion_upper or clasificacion_upper in key:
            return tipo
    # Por código de cuenta
    return "DESCONOCIDO"


def migrar_catalogo(session, verbose=True):
    """Lee el CSV del catálogo y carga las cuentas en la base de datos."""
    if not CATALOGO_CSV.exists():
        print(f"❌ Archivo no encontrado: {CATALOGO_CSV}")
        return 0

    print(f"📄 Leyendo: {CATALOGO_CSV.name}")

    # Intentar diferentes encodings
    for encoding in ["utf-8", "latin-1", "cp1252"]:
        try:
            df = pd.read_csv(CATALOGO_CSV, sep=";", encoding=encoding, dtype=str)
            break
        except Exception:
            continue
    else:
        print("❌ No se pudo leer el CSV con ningún encoding.")
        return 0

    print(f"   Columnas encontradas: {list(df.columns)}")
    print(f"   Total filas: {len(df)}")

    cuentas_creadas = 0
    cuentas_actualizadas = 0
    errores = 0

    for idx, row in df.iterrows():
        try:
            # La columna 'Account' contiene el código y nombre
            account_raw = str(row.get("Account", "")).strip()
            if not account_raw or account_raw == "nan":
                continue

            codigo = limpiar_codigo(account_raw)
            nombre = limpiar_nombre(account_raw)

            if not codigo:
                continue

            # Saldo inicial (columna SALDO, primera o última)
            saldo_cols = [c for c in df.columns if "SALDO" in c.upper()]
            saldo_inicial = 0.0
            for col in saldo_cols:
                val = str(row.get(col, "")).strip()
                if val and val != "nan":
                    try:
                        saldo_inicial = float(val.replace(",", "."))
                        break
                    except ValueError:
                        pass

            # Clasificación
            clasificacion = ""
            for col in df.columns:
                if "CLASIF" in col.upper():
                    val = str(row.get(col, "")).strip()
                    if val and val != "nan":
                        clasificacion = val
                        break

            tipo = determinar_tipo(clasificacion)

            # Extraer cuenta padre (primeros 4 dígitos del código)
            cuenta_padre = None
            if len(codigo) > 4:
                cuenta_padre = codigo[:4]

            # Verificar si ya existe
            cuenta_existente = session.query(CuentaContable).filter_by(codigo=codigo).first()

            if cuenta_existente:
                cuenta_existente.nombre = nombre
                cuenta_existente.saldo_inicial = saldo_inicial
                cuenta_existente.saldo_actual = saldo_inicial
                cuenta_existente.clasificacion = clasificacion
                cuenta_existente.tipo = tipo
                cuenta_existente.updated_at = datetime.utcnow()
                cuentas_actualizadas += 1
            else:
                nueva_cuenta = CuentaContable(
                    codigo=codigo,
                    nombre=nombre,
                    cuenta_padre=cuenta_padre,
                    clasificacion=clasificacion,
                    tipo=tipo,
                    saldo_inicial=saldo_inicial,
                    saldo_actual=saldo_inicial,
                    activa=True
                )
                session.add(nueva_cuenta)
                cuentas_creadas += 1

            if verbose and (cuentas_creadas + cuentas_actualizadas) % 20 == 0:
                print(f"   Procesadas {cuentas_creadas + cuentas_actualizadas} cuentas...")

        except Exception as e:
            errores += 1
            if verbose:
                print(f"   ⚠️  Error en fila {idx}: {e}")

    session.commit()
    print(f"\n✅ Migración completada:")
    print(f"   Cuentas nuevas:      {cuentas_creadas}")
    print(f"   Cuentas actualizadas:{cuentas_actualizadas}")
    print(f"   Errores:             {errores}")
    return cuentas_creadas + cuentas_actualizadas


def crear_periodos_iniciales(session):
    """Crea los períodos contables iniciales para 2026."""
    periodos_data = [
        ("Enero 2026",     datetime(2026, 1, 1),  datetime(2026, 1, 31)),
        ("Febrero 2026",   datetime(2026, 2, 1),  datetime(2026, 2, 28)),
        ("Marzo 2026",     datetime(2026, 3, 1),  datetime(2026, 3, 31)),
        ("Abril 2026",     datetime(2026, 4, 1),  datetime(2026, 4, 30)),
        ("Mayo 2026",      datetime(2026, 5, 1),  datetime(2026, 5, 31)),
        ("Junio 2026",     datetime(2026, 6, 1),  datetime(2026, 6, 30)),
        ("Julio 2026",     datetime(2026, 7, 1),  datetime(2026, 7, 31)),
        ("Agosto 2026",    datetime(2026, 8, 1),  datetime(2026, 8, 31)),
        ("Septiembre 2026",datetime(2026, 9, 1),  datetime(2026, 9, 30)),
        ("Octubre 2026",   datetime(2026, 10, 1), datetime(2026, 10, 31)),
        ("Noviembre 2026", datetime(2026, 11, 1), datetime(2026, 11, 30)),
        ("Diciembre 2026", datetime(2026, 12, 1), datetime(2026, 12, 31)),
    ]

    creados = 0
    for nombre, inicio, fin in periodos_data:
        existente = session.query(Periodo).filter_by(nombre=nombre).first()
        if not existente:
            periodo = Periodo(nombre=nombre, fecha_inicio=inicio, fecha_fin=fin, cerrado=False)
            session.add(periodo)
            creados += 1

    session.commit()
    print(f"✅ {creados} períodos creados para 2026.")


def ejecutar_migracion():
    """Función principal de migración."""
    print("=" * 60)
    print("  MIGRACION CSV -> SQLite")
    print("  Sistema Contable — REPASTADORA DEL SUR, S.A.")
    print("=" * 60)

    # 1. Crear tablas
    print("\n📋 Creando estructura de base de datos...")
    crear_tablas()

    # 2. Abrir sesión
    session = get_session()

    try:
        # 3. Migrar catálogo
        print("\n📊 Migrando catálogo de cuentas...")
        total = migrar_catalogo(session)

        # 4. Crear períodos
        print("\n📅 Creando períodos contables 2026...")
        crear_periodos_iniciales(session)

        print(f"\n{'=' * 60}")
        print(f"  ✅ MIGRACIÓN EXITOSA — {total} cuentas importadas")
        print(f"{'=' * 60}")

    except Exception as e:
        session.rollback()
        print(f"\n❌ Error durante la migración: {e}")
        raise
    finally:
        session.close()


if __name__ == "__main__":
    ejecutar_migracion()
