"""
database.py — Motor de Base de Datos SQLite con SQLAlchemy
Sistema Contable — REPASTADORA DEL SUR, S.A.
"""

import os
from datetime import datetime
from pathlib import Path

from sqlalchemy import (
    Column, Integer, String, Float, Boolean, DateTime,
    ForeignKey, Text, create_engine, Index
)
from sqlalchemy.orm import DeclarativeBase, relationship, sessionmaker, Session
from sqlalchemy.sql import func

# ─── Ruta de la base de datos ──────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "contable.db"
DATABASE_URL = f"sqlite:///{DB_PATH}"

# ─── Configuración del motor ────────────────────────────────────────────────
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


# ─── Base declarativa ───────────────────────────────────────────────────────
class Base(DeclarativeBase):
    pass


# ─── Modelos ORM ────────────────────────────────────────────────────────────

class CuentaContable(Base):
    """Catálogo de cuentas contables."""
    __tablename__ = "cuentas_contables"

    id = Column(Integer, primary_key=True, index=True)
    codigo = Column(String(20), unique=True, nullable=False, index=True)
    nombre = Column(String(200), nullable=False)
    cuenta_padre = Column(String(20), ForeignKey("cuentas_contables.codigo"), nullable=True)
    clasificacion = Column(String(100), nullable=True)
    tipo = Column(String(20), nullable=True)   # ACTIVO, PASIVO, CAPITAL, INGRESO, GASTO
    saldo_inicial = Column(Float, default=0.0)
    saldo_actual = Column(Float, default=0.0)
    activa = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relaciones
    lineas = relationship("LineaAsiento", back_populates="cuenta")

    def __repr__(self):
        return f"<Cuenta {self.codigo} — {self.nombre}>"


class Periodo(Base):
    """Períodos contables (mes/año)."""
    __tablename__ = "periodos"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(50), nullable=False)        # Ej: "Enero 2026"
    fecha_inicio = Column(DateTime, nullable=False)
    fecha_fin = Column(DateTime, nullable=False)
    cerrado = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    asientos = relationship("Asiento", back_populates="periodo")

    def __repr__(self):
        return f"<Periodo {self.nombre}>"


class Asiento(Base):
    """Asiento contable (cabecera de la transacción)."""
    __tablename__ = "asientos"

    id = Column(Integer, primary_key=True, index=True)
    numero = Column(String(20), unique=True, nullable=False)  # Ej: "AST-2026-001"
    fecha = Column(DateTime, nullable=False, default=datetime.utcnow)
    descripcion = Column(Text, nullable=False)
    referencia = Column(String(100), nullable=True)   # No. factura, comprobante
    tipo = Column(String(30), default="MANUAL")       # MANUAL, OCR, IA
    total_debe = Column(Float, default=0.0)
    total_haber = Column(Float, default=0.0)
    balanceado = Column(Boolean, default=False)
    periodo_id = Column(Integer, ForeignKey("periodos.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    periodo = relationship("Periodo", back_populates="asientos")
    lineas = relationship("LineaAsiento", back_populates="asiento", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Asiento {self.numero} — {self.descripcion[:40]}>"


class LineaAsiento(Base):
    """Línea individual de un asiento contable (débito o crédito)."""
    __tablename__ = "lineas_asiento"

    id = Column(Integer, primary_key=True, index=True)
    asiento_id = Column(Integer, ForeignKey("asientos.id"), nullable=False)
    cuenta_codigo = Column(String(20), ForeignKey("cuentas_contables.codigo"), nullable=False)
    descripcion = Column(String(200), nullable=True)
    debe = Column(Float, default=0.0)
    haber = Column(Float, default=0.0)

    asiento = relationship("Asiento", back_populates="lineas")
    cuenta = relationship("CuentaContable", back_populates="lineas")

    def __repr__(self):
        return f"<Linea {self.cuenta_codigo} D:{self.debe} H:{self.haber}>"


class DocumentoOCR(Base):
    """Documentos procesados por OCR (facturas, comprobantes)."""
    __tablename__ = "documentos_ocr"

    id = Column(Integer, primary_key=True, index=True)
    nombre_archivo = Column(String(200), nullable=False)
    tipo_documento = Column(String(50), nullable=True)   # FACTURA, COMPROBANTE, etc.
    texto_extraido = Column(Text, nullable=True)
    monto = Column(Float, nullable=True)
    fecha_documento = Column(DateTime, nullable=True)
    proveedor = Column(String(200), nullable=True)
    procesado = Column(Boolean, default=False)
    asiento_id = Column(Integer, ForeignKey("asientos.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<DocumentoOCR {self.nombre_archivo}>"


class ConfiguracionEmpresa(Base):
    """Datos generales de la empresa usados en el sistema y sus reportes."""
    __tablename__ = "configuracion_empresa"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String(200), nullable=False, default="REPASTADORA DEL SUR, S.A.")
    ruc = Column(String(50), nullable=True, default="")
    direccion = Column(String(300), nullable=True, default="")
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f"<Empresa {self.nombre}>"


# ─── Índices adicionales ─────────────────────────────────────────────────────
Index("ix_asientos_fecha", Asiento.fecha)
Index("ix_lineas_cuenta", LineaAsiento.cuenta_codigo)


# ─── Funciones utilitarias ───────────────────────────────────────────────────

def crear_tablas():
    """Crea todas las tablas en la base de datos."""
    Base.metadata.create_all(bind=engine)
    print(f"✅ Tablas creadas en: {DB_PATH}")


def get_db() -> Session:
    """Generador de sesión para uso con context manager."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_session() -> Session:
    """Retorna una sesión para uso directo (no generador)."""
    return SessionLocal()


if __name__ == "__main__":
    crear_tablas()
