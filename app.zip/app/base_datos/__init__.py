# Módulo base_datos — Motor de datos SQLite
