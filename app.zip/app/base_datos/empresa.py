"""Gestión de los datos generales de la empresa."""

from sqlalchemy.orm import Session

from app.base_datos.database import Base, ConfiguracionEmpresa, engine, get_session


DATOS_EMPRESA_POR_DEFECTO = {
    "nombre": "REPASTADORA DEL SUR, S.A.",
    "ruc": "",
    "direccion": "",
}


def obtener_datos_empresa(session: Session = None) -> dict:
    """Retorna los datos de empresa, creando la configuración inicial si hace falta."""
    Base.metadata.create_all(bind=engine)
    close = session is None
    if session is None:
        session = get_session()
    try:
        empresa = session.query(ConfiguracionEmpresa).order_by(ConfiguracionEmpresa.id).first()
        if not empresa:
            empresa = ConfiguracionEmpresa(**DATOS_EMPRESA_POR_DEFECTO)
            session.add(empresa)
            session.commit()
            session.refresh(empresa)
        return {
            "nombre": empresa.nombre,
            "ruc": empresa.ruc or "",
            "direccion": empresa.direccion or "",
        }
    finally:
        if close:
            session.close()


def guardar_datos_empresa(nombre: str, ruc: str = "", direccion: str = "", session: Session = None) -> dict:
    """Guarda y retorna los datos generales de la empresa."""
    nombre = (nombre or "").strip()
    if not nombre:
        raise ValueError("El nombre de la empresa es obligatorio")

    Base.metadata.create_all(bind=engine)
    close = session is None
    if session is None:
        session = get_session()
    try:
        empresa = session.query(ConfiguracionEmpresa).order_by(ConfiguracionEmpresa.id).first()
        if not empresa:
            empresa = ConfiguracionEmpresa()
            session.add(empresa)
        empresa.nombre = nombre
        empresa.ruc = (ruc or "").strip()
        empresa.direccion = (direccion or "").strip()
        session.commit()
        return {
            "nombre": empresa.nombre,
            "ruc": empresa.ruc or "",
            "direccion": empresa.direccion or "",
        }
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()
