# Módulo modelos — Integración con LLM (Ollama / Gemini)
