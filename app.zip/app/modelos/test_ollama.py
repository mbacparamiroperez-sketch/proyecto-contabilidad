import os
import ollama
from dotenv import load_dotenv

load_dotenv()

def test_conexion():
    modelo = os.getenv("OLLAMA_MODEL", "gemma4:2e2b")
    
    respuesta = ollama.chat(
        model=modelo,
        messages=[{
            "role": "user",
            "content": "Responde solo con: CONEXIÓN OK"
        }]
    )
    
    print(f"Modelo: {modelo}")
    print(f"Respuesta: {respuesta['message']['content']}")

if __name__ == "__main__":
    test_conexion()