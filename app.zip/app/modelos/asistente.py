"""
asistente.py — Asistente Contable con IA (Ollama/Gemma)
Responde preguntas financieras sobre los datos del sistema.
"""

import os
from typing import Optional, List
from dotenv import load_dotenv

load_dotenv()

try:
    import ollama
    OLLAMA_DISPONIBLE = True
except ImportError:
    OLLAMA_DISPONIBLE = False

OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma4:e4b")


PROMPT_SISTEMA = """Eres un asistente contable experto de REPASTADORA DEL SUR, S.A.,
una empresa ganadera nicaragüense. Tienes acceso a sus datos financieros.
Responde en español, de forma clara y profesional.
Cuando menciones montos, usa el formato C$ con separadores de miles.
Si no tienes datos suficientes para responder, dilo claramente."""


def _construir_contexto_financiero(resumen: dict) -> str:
    """Construye un resumen de contexto financiero para el LLM."""
    lineas = ["=== DATOS FINANCIEROS ACTUALES ==="]
    for tipo, total in resumen.items():
        lineas.append(f"{tipo}: C$ {total:,.2f}")
    return "\n".join(lineas)


def preguntar(
    pregunta: str,
    contexto_financiero: dict = None,
    historial: List[dict] = None
) -> str:
    """
    Envía una pregunta al asistente IA con contexto financiero.

    Args:
        pregunta: Pregunta del usuario.
        contexto_financiero: Dict con resumen de saldos por tipo.
        historial: Lista de mensajes anteriores para contexto de conversación.

    Returns:
        Respuesta del modelo como string.
    """
    if not OLLAMA_DISPONIBLE:
        return "❌ La librería 'ollama' no está instalada. Ejecuta: pip install ollama"

    mensajes = []

    # Sistema
    sistema = PROMPT_SISTEMA
    if contexto_financiero:
        sistema += "\n\n" + _construir_contexto_financiero(contexto_financiero)

    mensajes.append({"role": "system", "content": sistema})

    # Historial previo
    if historial:
        mensajes.extend(historial[-10:])  # Últimos 10 mensajes para no sobrepasar contexto

    # Pregunta actual
    mensajes.append({"role": "user", "content": pregunta})

    try:
        respuesta = ollama.chat(
            model=OLLAMA_MODEL,
            messages=mensajes,
            think=False,
            options={"num_predict": 512},
        )
        return respuesta["message"]["content"]
    except Exception as e:
        error_str = str(e)
        if "connection" in error_str.lower() or "refused" in error_str.lower():
            return (
                "⚠️ No se puede conectar con Ollama. "
                "Asegúrate de que Ollama esté en ejecución: "
                f"`ollama serve` y que el modelo '{OLLAMA_MODEL}' esté descargado."
            )
        return f"❌ Error del asistente: {error_str}"


def clasificar_transaccion_ocr(texto_ocr: str, cuentas_disponibles: List[dict] = None) -> dict:
    """
    Usa IA para sugerir el asiento contable de un documento OCR.

    Args:
        texto_ocr: Texto extraído del documento.
        cuentas_disponibles: Lista de cuentas del catálogo.

    Returns:
        Dict con sugerencia de asiento: descripcion, lineas sugeridas.
    """
    if not OLLAMA_DISPONIBLE:
        return {"error": "Ollama no disponible"}

    cuentas_str = ""
    if cuentas_disponibles:
        sample = cuentas_disponibles[:20]  # Muestra representativa
        cuentas_str = "\n".join([f"- {c['codigo']}: {c['nombre']}" for c in sample])

    prompt = f"""Analiza este documento contable y sugiere el asiento de diario:

TEXTO DEL DOCUMENTO:
{texto_ocr[:1000]}

CUENTAS DISPONIBLES (muestra):
{cuentas_str}

Responde SOLO en este formato JSON:
{{
  "descripcion": "descripción breve del asiento",
  "lineas": [
    {{"cuenta": "CODIGO", "nombre": "NOMBRE", "debe": 0.0, "haber": 0.0}},
    {{"cuenta": "CODIGO", "nombre": "NOMBRE", "debe": 0.0, "haber": 0.0}}
  ]
}}"""

    try:
        respuesta = ollama.chat(
            model=OLLAMA_MODEL,
            messages=[{"role": "user", "content": prompt}],
            think=False,
            options={"num_predict": 512},
        )
        import json
        texto_resp = respuesta["message"]["content"]
        # Intentar extraer JSON
        import re
        json_match = re.search(r'\{.*\}', texto_resp, re.DOTALL)
        if json_match:
            return json.loads(json_match.group())
        return {"sugerencia_texto": texto_resp}
    except Exception as e:
        return {"error": str(e)}


def verificar_conexion() -> bool:
    """Verifica Ollama y el modelo sin ejecutar una generación de texto."""
    if not OLLAMA_DISPONIBLE:
        return False
    try:
        modelos = ollama.list()
        nombres = {
            getattr(modelo, "model", None) or getattr(modelo, "name", None)
            for modelo in modelos.models
        }
        return OLLAMA_MODEL in nombres
    except Exception:
        return False
