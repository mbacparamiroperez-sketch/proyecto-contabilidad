"""
importador_asientos.py - Importacion de asientos desde archivos Excel.
"""

from datetime import datetime
from io import BytesIO
from typing import BinaryIO
import unicodedata

import pandas as pd
from sqlalchemy.orm import Session

from app.base_datos.database import get_session
from app.contabilidad.asientos import registrar_asiento
from app.contabilidad.catalogo import obtener_por_codigo


COLUMNAS_PLANTILLA = [
    "ID_ASIENTO",
    "FECHA",
    "DESCRIPCION",
    "REFERENCIA",
    "CUENTA",
    "DEBE",
    "HABER",
]

_ALIASES = {
    "ID": "ID_ASIENTO",
    "ID_ASIENTO": "ID_ASIENTO",
    "ASIENTO": "ID_ASIENTO",
    "NUMERO_ASIENTO": "ID_ASIENTO",
    "FECHA": "FECHA",
    "DATE": "FECHA",
    "DESCRIPCION": "DESCRIPCION",
    "CONCEPTO": "DESCRIPCION",
    "DETALLE": "DESCRIPCION",
    "REFERENCIA": "REFERENCIA",
    "DOCUMENTO": "REFERENCIA",
    "CUENTA": "CUENTA",
    "CODIGO": "CUENTA",
    "CODIGO_CUENTA": "CUENTA",
    "CUENTA_CODIGO": "CUENTA",
    "DEBE": "DEBE",
    "HABER": "HABER",
}


def _normalizar_columna(valor) -> str:
    texto = unicodedata.normalize("NFKD", str(valor))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return "_".join(texto.strip().upper().replace("-", " ").split())


def _normalizar_codigo(valor) -> str:
    if pd.isna(valor):
        return ""
    texto = str(valor).strip()
    if texto.endswith(".0") and texto[:-2].isdigit():
        texto = texto[:-2]
    return texto


def _normalizar_monto(valor, fila: int, columna: str) -> float:
    if pd.isna(valor) or str(valor).strip() == "":
        return 0.0
    monto = pd.to_numeric(valor, errors="coerce")
    if pd.isna(monto):
        raise ValueError(f"Fila {fila}: {columna} debe ser numerico.")
    monto = float(monto)
    if monto < 0:
        raise ValueError(f"Fila {fila}: {columna} no puede ser negativo.")
    return monto


def leer_asientos_excel(archivo) -> list[dict]:
    """Lee y valida la estructura del Excel, agrupando sus filas por asiento."""
    try:
        datos = pd.read_excel(archivo, engine="openpyxl")
    except Exception as error:
        raise ValueError(f"No se pudo leer el Excel: {error}") from error

    columnas = {}
    for columna in datos.columns:
        nombre = _ALIASES.get(_normalizar_columna(columna))
        if nombre and nombre not in columnas:
            columnas[nombre] = columna

    requeridas = {"FECHA", "DESCRIPCION", "CUENTA", "DEBE", "HABER"}
    faltantes = sorted(requeridas - set(columnas))
    if faltantes:
        raise ValueError("Faltan columnas obligatorias: " + ", ".join(faltantes))

    grupos = {}
    orden = []
    for indice, fila in datos.iterrows():
        numero_fila = indice + 2
        if all(pd.isna(fila.get(columna)) for columna in columnas.values()):
            continue

        fecha = pd.to_datetime(fila[columnas["FECHA"]], errors="coerce")
        if pd.isna(fecha):
            raise ValueError(f"Fila {numero_fila}: FECHA no valida.")
        descripcion = str(fila[columnas["DESCRIPCION"]]).strip()
        if not descripcion or descripcion.lower() == "nan":
            raise ValueError(f"Fila {numero_fila}: DESCRIPCION es obligatoria.")

        codigo = _normalizar_codigo(fila[columnas["CUENTA"]])
        if not codigo:
            raise ValueError(f"Fila {numero_fila}: CUENTA es obligatoria.")
        debe = _normalizar_monto(fila[columnas["DEBE"]], numero_fila, "DEBE")
        haber = _normalizar_monto(fila[columnas["HABER"]], numero_fila, "HABER")
        if debe == 0 and haber == 0:
            raise ValueError(f"Fila {numero_fila}: DEBE o HABER debe tener un monto.")

        referencia = ""
        if "REFERENCIA" in columnas and not pd.isna(fila[columnas["REFERENCIA"]]):
            referencia = str(fila[columnas["REFERENCIA"]]).strip()
        identificador = ""
        if "ID_ASIENTO" in columnas and not pd.isna(fila[columnas["ID_ASIENTO"]]):
            identificador = str(fila[columnas["ID_ASIENTO"]]).strip()
        clave = identificador or (
            fecha.strftime("%Y-%m-%d"), descripcion, referencia
        )
        if clave not in grupos:
            grupos[clave] = {
                "fecha": fecha.to_pydatetime(),
                "descripcion": descripcion,
                "referencia": referencia or None,
                "lineas": [],
            }
            orden.append(clave)
        grupos[clave]["lineas"].append((codigo, debe, haber))

    if not orden:
        raise ValueError("El Excel no contiene filas de asientos.")

    asientos = [grupos[clave] for clave in orden]
    for indice, asiento in enumerate(asientos, 1):
        if len(asiento["lineas"]) < 2:
            raise ValueError(f"El asiento {indice} debe tener al menos 2 lineas.")
        total_debe = round(sum(linea[1] for linea in asiento["lineas"]), 4)
        total_haber = round(sum(linea[2] for linea in asiento["lineas"]), 4)
        if abs(total_debe - total_haber) >= 0.01:
            raise ValueError(
                f"El asiento {indice} no cuadra: DEBE={total_debe:,.2f} "
                f"y HABER={total_haber:,.2f}."
            )
    return asientos


def importar_asientos_excel(archivo, session: Session = None) -> dict:
    """Valida y registra todos los asientos contenidos en un Excel."""
    asientos = leer_asientos_excel(archivo)
    close = session is None
    if session is None:
        session = get_session()
    try:
        for indice, asiento in enumerate(asientos, 1):
            for codigo, _, _ in asiento["lineas"]:
                cuenta = obtener_por_codigo(codigo, session)
                if not cuenta:
                    raise ValueError(f"Asiento {indice}: cuenta no encontrada: {codigo}")
                if not cuenta.activa:
                    raise ValueError(f"Asiento {indice}: cuenta inactiva: {codigo}")

        registrados = []
        for asiento in asientos:
            registrado = registrar_asiento(
                descripcion=asiento["descripcion"],
                lineas=asiento["lineas"],
                fecha=asiento["fecha"],
                referencia=asiento["referencia"],
                tipo="EXCEL",
                session=session,
            )
            registrados.append(registrado.numero)
        return {"cantidad": len(registrados), "numeros": registrados}
    finally:
        if close:
            session.close()


def crear_plantilla_asientos() -> bytes:
    """Genera una plantilla Excel descargable para la carga de asientos."""
    ejemplo = pd.DataFrame([
        ["ASIENTO-001", datetime.now().date(), "Ejemplo de asiento", "DOC-001", "110101", 1000.0, 0.0],
        ["ASIENTO-001", datetime.now().date(), "Ejemplo de asiento", "DOC-001", "210101", 0.0, 1000.0],
    ], columns=COLUMNAS_PLANTILLA)
    salida = BytesIO()
    with pd.ExcelWriter(salida, engine="openpyxl") as escritor:
        ejemplo.to_excel(escritor, index=False, sheet_name="Asientos")
    return salida.getvalue()
