"""
diario.py — Libro Diario
Lista cronológica de todos los asientos contables registrados.
"""

from datetime import datetime
from typing import List, Optional
from sqlalchemy.orm import Session

from app.base_datos.database import Asiento, LineaAsiento, get_session


def obtener_libro_diario(
    desde: datetime = None,
    hasta: datetime = None,
    tipo: str = None,
    limite: int = 200,
    session: Session = None
) -> List[dict]:
    """
    Retorna el libro diario con detalle de líneas.

    Returns:
        Lista de dicts con: numero, fecha, descripcion, referencia, lineas[], total_debe, total_haber
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        q = session.query(Asiento).order_by(Asiento.fecha.asc(), Asiento.numero.asc())
        if desde:
            q = q.filter(Asiento.fecha >= desde)
        if hasta:
            q = q.filter(Asiento.fecha <= hasta)
        if tipo:
            q = q.filter(Asiento.tipo == tipo.upper())

        asientos = q.limit(limite).all()
        resultado = []

        for a in asientos:
            lineas = []
            for l in a.lineas:
                lineas.append({
                    "cuenta_codigo": l.cuenta_codigo,
                    "cuenta_nombre": l.cuenta.nombre if l.cuenta else "—",
                    "debe": l.debe,
                    "haber": l.haber,
                })
            resultado.append({
                "numero": a.numero,
                "fecha": a.fecha,
                "descripcion": a.descripcion,
                "referencia": a.referencia or "—",
                "tipo": a.tipo,
                "total_debe": a.total_debe,
                "total_haber": a.total_haber,
                "balanceado": a.balanceado,
                "lineas": lineas,
            })

        return resultado
    finally:
        if close:
            session.close()


def asientos_por_cuenta(
    codigo_cuenta: str,
    desde: datetime = None,
    hasta: datetime = None,
    session: Session = None
) -> List[dict]:
    """
    Retorna todos los asientos que afectan a una cuenta específica.
    Útil para ver el libro mayor de esa cuenta.
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        q = (
            session.query(LineaAsiento)
            .filter_by(cuenta_codigo=codigo_cuenta)
            .join(Asiento)
            .order_by(Asiento.fecha.asc())
        )
        if desde:
            q = q.filter(Asiento.fecha >= desde)
        if hasta:
            q = q.filter(Asiento.fecha <= hasta)

        lineas = q.all()
        return [
            {
                "numero_asiento": l.asiento.numero,
                "fecha": l.asiento.fecha,
                "descripcion": l.asiento.descripcion,
                "referencia": l.asiento.referencia,
                "debe": l.debe,
                "haber": l.haber,
            }
            for l in lineas
        ]
    finally:
        if close:
            session.close()


def resumen_movimientos_por_rango(
    desde: datetime = None,
    hasta: datetime = None,
    session: Session = None
) -> dict:
    """Devuelve un resumen de movimientos en un rango de fechas."""
    close = session is None
    if session is None:
        session = get_session()

    try:
        q = (
            session.query(LineaAsiento)
            .join(Asiento)
            .order_by(Asiento.fecha.asc(), LineaAsiento.cuenta_codigo.asc())
        )
        if desde:
            q = q.filter(Asiento.fecha >= desde)
        if hasta:
            q = q.filter(Asiento.fecha <= hasta)

        lineas = q.all()
        movimientos = []
        total_debe = 0.0
        total_haber = 0.0
        numeros_asientos = set()

        for linea in lineas:
            asiento = linea.asiento
            if asiento:
                numeros_asientos.add(asiento.numero)
            total_debe += float(linea.debe or 0)
            total_haber += float(linea.haber or 0)
            movimientos.append({
                "numero_asiento": asiento.numero if asiento else "—",
                "cuenta": linea.cuenta_codigo,
                "nombre_cuenta": linea.cuenta.nombre if linea.cuenta else "—",
                "descripcion": asiento.descripcion if asiento else "—",
                "documentos": asiento.referencia or "—",
                "debe": float(linea.debe or 0),
                "haber": float(linea.haber or 0),
            })

        return {
            "movimientos": movimientos,
            "total_debe": round(total_debe, 2),
            "total_haber": round(total_haber, 2),
            "cantidad_asientos": len(numeros_asientos),
        }
    finally:
        if close:
            session.close()


def conteo_asientos(session: Session = None) -> dict:
    """Estadísticas rápidas del libro diario."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        total = session.query(Asiento).count()
        manuales = session.query(Asiento).filter_by(tipo="MANUAL").count()
        ocr = session.query(Asiento).filter_by(tipo="OCR").count()
        ia = session.query(Asiento).filter_by(tipo="IA").count()
        return {"total": total, "manuales": manuales, "ocr": ocr, "ia": ia}
    finally:
        if close:
            session.close()
