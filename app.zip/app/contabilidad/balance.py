"""
balance.py — Balance de Comprobación y Verificaciones Contables
"""

from typing import List
from sqlalchemy.orm import Session

from app.contabilidad.mayor import balance_comprobacion
from app.base_datos.database import get_session
from app.base_datos.empresa import obtener_datos_empresa


def generar_balance_comprobacion(session: Session = None) -> dict:
    """
    Genera el balance de comprobación completo con totales.

    Returns:
        Dict con: cuentas[], total_debe, total_haber, balanceado, diferencia
    """
    cuentas = balance_comprobacion(session)

    total_debe = round(sum(c["total_debe"] for c in cuentas), 2)
    total_haber = round(sum(c["total_haber"] for c in cuentas), 2)
    diferencia = round(abs(total_debe - total_haber), 2)
    balanceado = diferencia < 0.01

    empresa = obtener_datos_empresa(session)
    return {
        "empresa": empresa["nombre"],
        "ruc": empresa["ruc"],
        "direccion": empresa["direccion"],
        "titulo": "BALANZA DE COMPROBACIÓN / TRIAL BALANCE",
        "cuentas": cuentas,
        "total_debe": total_debe,
        "total_haber": total_haber,
        "balanceado": balanceado,
        "diferencia": diferencia,
    }


def verificar_ecuacion_contable(session: Session = None) -> dict:
    """
    Verifica que ACTIVOS = PASIVOS + CAPITAL.

    Returns:
        Dict con: total_activos, total_pasivos_capital, cuadra, diferencia
    """
    cuentas = balance_comprobacion(session)

    activos = round(sum(c["saldo_final"] for c in cuentas if c["tipo"] == "ACTIVO"), 2)
    pasivos = round(sum(c["saldo_final"] for c in cuentas if c["tipo"] == "PASIVO"), 2)
    capital = round(sum(c["saldo_final"] for c in cuentas if c["tipo"] == "CAPITAL"), 2)
    ingresos = round(sum(c["saldo_final"] for c in cuentas if c["tipo"] == "INGRESO"), 2)
    gastos = round(sum(c["saldo_final"] for c in cuentas if c["tipo"] == "GASTO"), 2)

    utilidad = round(abs(ingresos) - abs(gastos), 2)
    pasivos_capital_utilidad = round(abs(pasivos) + abs(capital) + utilidad, 2)
    diferencia = round(abs(activos - pasivos_capital_utilidad), 2)

    return {
        "total_activos": activos,
        "total_pasivos": abs(pasivos),
        "total_capital": abs(capital),
        "total_ingresos": abs(ingresos),
        "total_gastos": abs(gastos),
        "utilidad_periodo": utilidad,
        "total_pasivos_capital": pasivos_capital_utilidad,
        "cuadra": diferencia < 1.0,
        "diferencia": diferencia,
    }


def cuentas_con_saldo_negativo(session: Session = None) -> List[dict]:
    """Retorna cuentas de activo con saldo negativo (posible error)."""
    cuentas = balance_comprobacion(session)
    return [
        c for c in cuentas
        if c["tipo"] in ("ACTIVO",) and c["saldo_final"] < 0
    ]
