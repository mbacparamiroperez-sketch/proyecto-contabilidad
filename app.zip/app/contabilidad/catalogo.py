"""
catalogo.py — CRUD del Catálogo de Cuentas Contables
Sistema Contable — REPASTADORA DEL SUR, S.A.
"""

from typing import Optional, List
from sqlalchemy.orm import Session
from sqlalchemy import or_, func

from app.base_datos.database import CuentaContable, LineaAsiento, get_session


# ─── Consultas ───────────────────────────────────────────────────────────────

def obtener_todas(session: Session = None) -> List[CuentaContable]:
    """Retorna todas las cuentas activas ordenadas por código."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        return session.query(CuentaContable).filter_by(activa=True).order_by(CuentaContable.codigo).all()
    finally:
        if close:
            session.close()


def obtener_todas_incluyendo_inactivas(session: Session = None) -> List[CuentaContable]:
    """Retorna todas las cuentas, activas e inactivas, ordenadas por código."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        return session.query(CuentaContable).order_by(CuentaContable.codigo).all()
    finally:
        if close:
            session.close()


def obtener_por_codigo(codigo: str, session: Session = None) -> Optional[CuentaContable]:
    """Busca una cuenta por su código exacto."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        return session.query(CuentaContable).filter_by(codigo=codigo.strip()).first()
    finally:
        if close:
            session.close()


def buscar(termino: str, session: Session = None) -> List[CuentaContable]:
    """Busca cuentas por código o nombre (búsqueda parcial)."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        patron = f"%{termino.strip()}%"
        return (
            session.query(CuentaContable)
            .filter(
                CuentaContable.activa == True,
                or_(
                    CuentaContable.codigo.ilike(patron),
                    CuentaContable.nombre.ilike(patron),
                    CuentaContable.clasificacion.ilike(patron),
                )
            )
            .order_by(CuentaContable.codigo)
            .all()
        )
    finally:
        if close:
            session.close()


def obtener_por_tipo(tipo: str, session: Session = None) -> List[CuentaContable]:
    """Filtra cuentas por tipo: ACTIVO, PASIVO, CAPITAL, INGRESO, GASTO."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        return (
            session.query(CuentaContable)
            .filter_by(activa=True, tipo=tipo.upper())
            .order_by(CuentaContable.codigo)
            .all()
        )
    finally:
        if close:
            session.close()


def obtener_por_clasificacion(clasificacion: str, session: Session = None) -> List[CuentaContable]:
    """Filtra cuentas por clasificación (ej: EFECTIVO Y EQUIVALENTE)."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        patron = f"%{clasificacion}%"
        return (
            session.query(CuentaContable)
            .filter(
                CuentaContable.activa == True,
                CuentaContable.clasificacion.ilike(patron)
            )
            .order_by(CuentaContable.codigo)
            .all()
        )
    finally:
        if close:
            session.close()


def resumen_por_tipo(session: Session = None) -> dict:
    """Retorna totales de saldo agrupados por tipo de cuenta."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        resultados = (
            session.query(CuentaContable.tipo, func.sum(CuentaContable.saldo_actual))
            .filter_by(activa=True)
            .group_by(CuentaContable.tipo)
            .all()
        )
        return {tipo: round(total or 0.0, 2) for tipo, total in resultados}
    finally:
        if close:
            session.close()


# ─── Mutaciones ──────────────────────────────────────────────────────────────

def crear_cuenta(
    codigo: str,
    nombre: str,
    clasificacion: str = "",
    tipo: str = "DESCONOCIDO",
    saldo_inicial: float = 0.0,
    cuenta_padre: str = None,
    session: Session = None
) -> CuentaContable:
    """Crea una nueva cuenta contable."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        if obtener_por_codigo(codigo, session):
            raise ValueError(f"Ya existe una cuenta con el código {codigo}")

        cuenta = CuentaContable(
            codigo=codigo.strip(),
            nombre=nombre.strip(),
            clasificacion=clasificacion,
            tipo=tipo.upper(),
            saldo_inicial=saldo_inicial,
            saldo_actual=saldo_inicial,
            cuenta_padre=cuenta_padre,
            activa=True
        )
        session.add(cuenta)
        session.commit()
        session.refresh(cuenta)
        return cuenta
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def actualizar_cuenta(
    codigo: str,
    nombre: str,
    clasificacion: str = "",
    tipo: str = "DESCONOCIDO",
    cuenta_padre: str = None,
    session: Session = None
) -> CuentaContable:
    """Actualiza los datos descriptivos de una cuenta existente."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        cuenta = obtener_por_codigo(codigo, session)
        if not cuenta:
            raise ValueError(f"Cuenta {codigo} no encontrada")
        if not nombre or not nombre.strip():
            raise ValueError("El nombre de la cuenta es obligatorio")

        cuenta.nombre = nombre.strip()
        cuenta.clasificacion = clasificacion.strip()
        cuenta.tipo = tipo.upper()
        cuenta.cuenta_padre = cuenta_padre.strip() if cuenta_padre else None
        session.commit()
        session.refresh(cuenta)
        return cuenta
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def eliminar_cuenta(codigo: str, session: Session = None) -> bool:
    """Elimina una cuenta solo si no tiene saldos ni movimientos registrados."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        cuenta = obtener_por_codigo(codigo, session)
        if not cuenta:
            raise ValueError(f"Cuenta {codigo} no encontrada")
        if abs(cuenta.saldo_actual or 0.0) >= 0.01 or abs(cuenta.saldo_inicial or 0.0) >= 0.01:
            raise ValueError("No se puede eliminar una cuenta con saldo")
        if session.query(LineaAsiento).filter_by(cuenta_codigo=cuenta.codigo).first():
            raise ValueError("No se puede eliminar una cuenta con movimientos registrados")

        session.delete(cuenta)
        session.commit()
        return True
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def actualizar_saldo(codigo: str, nuevo_saldo: float, session: Session = None) -> CuentaContable:
    """Actualiza el saldo actual de una cuenta."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        cuenta = obtener_por_codigo(codigo, session)
        if not cuenta:
            raise ValueError(f"Cuenta {codigo} no encontrada")
        cuenta.saldo_actual = round(nuevo_saldo, 4)
        session.commit()
        session.refresh(cuenta)
        return cuenta
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def desactivar_cuenta(codigo: str, session: Session = None) -> bool:
    """Desactiva (elimina lógicamente) una cuenta."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        cuenta = obtener_por_codigo(codigo, session)
        if not cuenta:
            return False
        cuenta.activa = False
        session.commit()
        return True
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def reactivar_cuenta(codigo: str, session: Session = None) -> bool:
    """Reactiva una cuenta que había sido desactivada."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        cuenta = obtener_por_codigo(codigo, session)
        if not cuenta:
            return False
        cuenta.activa = True
        session.commit()
        return True
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


# ─── Utilidades ──────────────────────────────────────────────────────────────

def total_activos(session: Session = None) -> float:
    """Calcula el total de activos (saldo actual)."""
    resumen = resumen_por_tipo(session)
    return resumen.get("ACTIVO", 0.0)


def total_pasivos(session: Session = None) -> float:
    """Calcula el total de pasivos."""
    resumen = resumen_por_tipo(session)
    return resumen.get("PASIVO", 0.0)


def total_capital(session: Session = None) -> float:
    """Calcula el total de capital."""
    resumen = resumen_por_tipo(session)
    return resumen.get("CAPITAL", 0.0)


if __name__ == "__main__":
    print("Resumen de saldos por tipo:")
    resumen = resumen_por_tipo()
    for tipo, total in resumen.items():
        print(f"  {tipo:15s}: C$ {total:>15,.2f}")
