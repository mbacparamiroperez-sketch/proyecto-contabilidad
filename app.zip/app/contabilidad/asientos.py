"""
asientos.py — Registro y Validación de Asientos Contables
Implementa la partida doble: DEBE = HABER
"""

from datetime import datetime
from typing import List, Tuple, Optional
from sqlalchemy.orm import Session

from app.base_datos.database import Asiento, LineaAsiento, CuentaContable, get_session
from app.contabilidad.catalogo import obtener_por_codigo, actualizar_saldo


# ─── Generar número de asiento ───────────────────────────────────────────────

def _siguiente_numero(session: Session) -> str:
    """Genera el próximo número de asiento: AST-2026-001, AST-2026-002, ..."""
    anio = datetime.utcnow().year
    prefijo = f"AST-{anio}-"
    ultimo = (
        session.query(Asiento)
        .filter(Asiento.numero.like(f"{prefijo}%"))
        .order_by(Asiento.numero.desc())
        .first()
    )
    if ultimo:
        try:
            seq = int(ultimo.numero.split("-")[-1]) + 1
        except ValueError:
            seq = 1
    else:
        seq = 1
    return f"{prefijo}{seq:04d}"


# ─── Creación de asientos ────────────────────────────────────────────────────

def registrar_asiento(
    descripcion: str,
    lineas: List[Tuple[str, float, float]],
    fecha: datetime = None,
    referencia: str = None,
    tipo: str = "MANUAL",
    periodo_id: int = None,
    session: Session = None
) -> Asiento:
    """
    Registra un asiento contable con validación de partida doble.

    Args:
        descripcion: Descripción del asiento.
        lineas: Lista de tuplas (codigo_cuenta, debe, haber).
        fecha: Fecha del asiento (default: ahora).
        referencia: No. documento de referencia.
        tipo: "MANUAL", "OCR" o "IA".
        periodo_id: ID del período contable.
        session: Sesión de BD (opcional).

    Returns:
        El asiento creado.

    Raises:
        ValueError: Si la partida doble no cuadra o faltan datos.
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        if not lineas:
            raise ValueError("El asiento debe tener al menos una línea.")

        # Calcular totales
        total_debe = round(sum(d for _, d, _ in lineas), 4)
        total_haber = round(sum(h for _, _, h in lineas), 4)
        balanceado = abs(total_debe - total_haber) < 0.01

        if not balanceado:
            raise ValueError(
                f"Partida doble no cuadra: DEBE={total_debe:,.2f} ≠ HABER={total_haber:,.2f}"
            )

        # Validar cuentas
        for codigo, _, _ in lineas:
            cuenta = obtener_por_codigo(codigo, session)
            if not cuenta:
                raise ValueError(f"Cuenta no encontrada: {codigo}")
            if not cuenta.activa:
                raise ValueError(f"Cuenta inactiva: {codigo} — {cuenta.nombre}")

        # Crear asiento
        numero = _siguiente_numero(session)
        asiento = Asiento(
            numero=numero,
            fecha=fecha or datetime.utcnow(),
            descripcion=descripcion.strip(),
            referencia=referencia,
            tipo=tipo,
            total_debe=total_debe,
            total_haber=total_haber,
            balanceado=True,
            periodo_id=periodo_id
        )
        session.add(asiento)
        session.flush()  # Obtener ID del asiento

        # Crear líneas y actualizar saldos
        for codigo, debe, haber in lineas:
            linea = LineaAsiento(
                asiento_id=asiento.id,
                cuenta_codigo=codigo,
                debe=round(debe, 4),
                haber=round(haber, 4)
            )
            session.add(linea)

            # Actualizar saldo de la cuenta
            cuenta = obtener_por_codigo(codigo, session)
            if cuenta:
                movimiento = debe - haber
                nuevo_saldo = cuenta.saldo_actual + movimiento
                cuenta.saldo_actual = round(nuevo_saldo, 4)

        session.commit()
        session.refresh(asiento)
        return asiento

    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


# ─── Consultas ───────────────────────────────────────────────────────────────

def obtener_asiento(numero: str, session: Session = None) -> Optional[Asiento]:
    """Busca un asiento por su número."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        return session.query(Asiento).filter_by(numero=numero).first()
    finally:
        if close:
            session.close()


def listar_asientos(
    desde: datetime = None,
    hasta: datetime = None,
    limite: int = 100,
    session: Session = None
) -> List[Asiento]:
    """Lista asientos en un rango de fechas."""
    close = session is None
    if session is None:
        session = get_session()
    try:
        q = session.query(Asiento).order_by(Asiento.fecha.desc())
        if desde:
            q = q.filter(Asiento.fecha >= desde)
        if hasta:
            q = q.filter(Asiento.fecha <= hasta)
        return q.limit(limite).all()
    finally:
        if close:
            session.close()


def anular_asiento(numero: str, session: Session = None) -> bool:
    """
    Anula un asiento contable creando un asiento inverso.
    No elimina el asiento original (integridad del historial).
    """
    close = session is None
    if session is None:
        session = get_session()
    try:
        asiento = obtener_asiento(numero, session)
        if not asiento:
            raise ValueError(f"Asiento {numero} no encontrado")

        # Crear líneas inversas
        lineas_inversas = [
            (l.cuenta_codigo, l.haber, l.debe)  # Invertir debe y haber
            for l in asiento.lineas
        ]

        registrar_asiento(
            descripcion=f"ANULACIÓN DE {asiento.numero}: {asiento.descripcion}",
            lineas=lineas_inversas,
            referencia=asiento.numero,
            tipo="ANULACION",
            periodo_id=asiento.periodo_id,
            session=session
        )
        return True
    except Exception:
        if not close:
            session.rollback()
        raise
    finally:
        if close:
            session.close()
