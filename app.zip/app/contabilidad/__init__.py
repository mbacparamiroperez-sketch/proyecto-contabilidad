# Módulo contabilidad — Lógica contable central
