"""
mayor.py — Libro Mayor
Movimientos por cuenta individual con saldo acumulado.
"""

from datetime import datetime
from typing import List, Optional
from sqlalchemy.orm import Session

from app.base_datos.database import CuentaContable, LineaAsiento, Asiento, get_session


def libro_mayor_cuenta(
    codigo: str,
    desde: datetime = None,
    hasta: datetime = None,
    session: Session = None
) -> dict:
    """
    Genera el libro mayor de una cuenta: movimientos + saldo acumulado.

    Returns:
        Dict con: cuenta, movimientos[], saldo_inicial, total_debe,
                  total_haber, saldo_final
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        cuenta = session.query(CuentaContable).filter_by(codigo=codigo).first()
        if not cuenta:
            raise ValueError(f"Cuenta {codigo} no encontrada")

        q = (
            session.query(LineaAsiento)
            .filter_by(cuenta_codigo=codigo)
            .join(Asiento)
            .order_by(Asiento.fecha.asc(), Asiento.numero.asc())
        )
        if desde:
            q = q.filter(Asiento.fecha >= desde)
        if hasta:
            q = q.filter(Asiento.fecha <= hasta)

        lineas = q.all()

        saldo_acumulado = cuenta.saldo_inicial
        movimientos = []

        for l in lineas:
            saldo_acumulado = round(saldo_acumulado + l.debe - l.haber, 4)
            movimientos.append({
                "fecha": l.asiento.fecha,
                "numero_asiento": l.asiento.numero,
                "descripcion": l.asiento.descripcion,
                "referencia": l.asiento.referencia,
                "debe": l.debe,
                "haber": l.haber,
                "saldo": saldo_acumulado,
            })

        total_debe = round(sum(m["debe"] for m in movimientos), 2)
        total_haber = round(sum(m["haber"] for m in movimientos), 2)

        return {
            "cuenta": {
                "codigo": cuenta.codigo,
                "nombre": cuenta.nombre,
                "tipo": cuenta.tipo,
                "clasificacion": cuenta.clasificacion,
            },
            "saldo_inicial": cuenta.saldo_inicial,
            "movimientos": movimientos,
            "total_debe": total_debe,
            "total_haber": total_haber,
            "saldo_final": round(cuenta.saldo_inicial + total_debe - total_haber, 2),
        }
    finally:
        if close:
            session.close()


def balance_comprobacion(session: Session = None) -> List[dict]:
    """
    Genera el balance de comprobación: todas las cuentas con sus movimientos totales.

    Returns:
        Lista ordenada por código con: codigo, nombre, tipo,
        saldo_inicial, total_debe, total_haber, saldo_final
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        cuentas = (
            session.query(CuentaContable)
            .filter_by(activa=True)
            .order_by(CuentaContable.codigo)
            .all()
        )

        resultado = []
        for cuenta in cuentas:
            movs = (
                session.query(LineaAsiento)
                .filter_by(cuenta_codigo=cuenta.codigo)
                .all()
            )
            total_debe = sum(m.debe for m in movs)
            total_haber = sum(m.haber for m in movs)
            saldo_final = cuenta.saldo_inicial + total_debe - total_haber

            resultado.append({
                "codigo": cuenta.codigo,
                "nombre": cuenta.nombre,
                "tipo": cuenta.tipo,
                "clasificacion": cuenta.clasificacion,
                "saldo_inicial": cuenta.saldo_inicial,
                "total_debe": total_debe,
                "total_haber": total_haber,
                "saldo_final": saldo_final,
            })

        return resultado
    finally:
        if close:
            session.close()
