"""
importador_catalogo.py - Plantilla e importacion del catalogo contable desde Excel.
"""

from io import BytesIO
import unicodedata

import pandas as pd
from sqlalchemy.orm import Session

from app.base_datos.database import CuentaContable, LineaAsiento, get_session
from app.base_datos.migrador import determinar_tipo


COLUMNAS_PLANTILLA = [
    "CODIGO",
    "NOMBRE",
    "CLASIFICACION",
    "TIPO",
    "SALDO_INICIAL",
    "CUENTA_PADRE",
]

_ALIASES = {
    "CODIGO": "CODIGO",
    "CUENTA": "CODIGO",
    "CODIGO_CUENTA": "CODIGO",
    "NOMBRE": "NOMBRE",
    "NOMBRE_CUENTA": "NOMBRE",
    "ACCOUNT": "NOMBRE",
    "CLASIFICACION": "CLASIFICACION",
    "TIPO": "TIPO",
    "SALDO": "SALDO_INICIAL",
    "SALDO_INICIAL": "SALDO_INICIAL",
    "CUENTA_PADRE": "CUENTA_PADRE",
    "PADRE": "CUENTA_PADRE",
}

TIPOS_VALIDOS = {"ACTIVO", "PASIVO", "CAPITAL", "INGRESO", "GASTO", "DESCONOCIDO"}


def _normalizar_columna(valor) -> str:
    texto = unicodedata.normalize("NFKD", str(valor))
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return "_".join(texto.strip().upper().replace("-", " ").split())


def _texto(valor) -> str:
    if pd.isna(valor):
        return ""
    return str(valor).strip()


def _codigo(valor) -> str:
    texto = _texto(valor)
    if texto.endswith(".0") and texto[:-2].isdigit():
        return texto[:-2]
    return texto


def _saldo(valor, fila: int) -> float:
    if pd.isna(valor) or _texto(valor) == "":
        return 0.0
    saldo = pd.to_numeric(valor, errors="coerce")
    if pd.isna(saldo):
        raise ValueError(f"Fila {fila}: SALDO_INICIAL debe ser numerico.")
    return float(saldo)


def leer_catalogo_excel(archivo) -> list[dict]:
    """Lee y valida un Excel de catalogo antes de modificar la base de datos."""
    try:
        datos = pd.read_excel(archivo, engine="openpyxl")
    except Exception as error:
        raise ValueError(f"No se pudo leer el Excel: {error}") from error

    columnas = {}
    for columna in datos.columns:
        nombre = _ALIASES.get(_normalizar_columna(columna))
        if nombre and nombre not in columnas:
            columnas[nombre] = columna

    requeridas = {"CODIGO", "NOMBRE", "CLASIFICACION"}
    faltantes = sorted(requeridas - set(columnas))
    if faltantes:
        raise ValueError("Faltan columnas obligatorias: " + ", ".join(faltantes))

    resultado = []
    codigos = set()
    for indice, fila in datos.iterrows():
        numero_fila = indice + 2
        if all(pd.isna(valor) for valor in fila):
            continue
        codigo = _codigo(fila[columnas["CODIGO"]])
        nombre = _texto(fila[columnas["NOMBRE"]])
        clasificacion = _texto(fila[columnas["CLASIFICACION"]])
        if not codigo or not nombre or not clasificacion:
            raise ValueError(f"Fila {numero_fila}: CODIGO, NOMBRE y CLASIFICACION son obligatorios.")
        if codigo in codigos:
            raise ValueError(f"Fila {numero_fila}: el código {codigo} está repetido en el archivo.")
        codigos.add(codigo)

        tipo = _texto(fila[columnas["TIPO"]]).upper() if "TIPO" in columnas else ""
        tipo = tipo or determinar_tipo(clasificacion)
        if tipo not in TIPOS_VALIDOS:
            raise ValueError(f"Fila {numero_fila}: TIPO no válido: {tipo}")
        saldo_inicial = _saldo(fila[columnas["SALDO_INICIAL"]], numero_fila) if "SALDO_INICIAL" in columnas else 0.0
        cuenta_padre = _codigo(fila[columnas["CUENTA_PADRE"]]) if "CUENTA_PADRE" in columnas else None
        resultado.append({
            "codigo": codigo,
            "nombre": nombre,
            "clasificacion": clasificacion,
            "tipo": tipo,
            "saldo_inicial": saldo_inicial,
            "cuenta_padre": cuenta_padre or None,
        })

    if not resultado:
        raise ValueError("El Excel no contiene cuentas.")
    return resultado


def importar_catalogo_excel(archivo, session: Session = None) -> dict:
    """Crea cuentas nuevas y actualiza cuentas existentes desde un Excel."""
    cuentas = leer_catalogo_excel(archivo)
    close = session is None
    if session is None:
        session = get_session()
    try:
        creadas = 0
        actualizadas = 0
        for cuenta_data in cuentas:
            existente = session.query(CuentaContable).filter_by(codigo=cuenta_data["codigo"]).first()
            if existente:
                existente.nombre = cuenta_data["nombre"]
                existente.clasificacion = cuenta_data["clasificacion"]
                existente.tipo = cuenta_data["tipo"]
                existente.cuenta_padre = cuenta_data["cuenta_padre"]
                movimientos = session.query(LineaAsiento).filter_by(cuenta_codigo=existente.codigo).count()
                if movimientos == 0:
                    existente.saldo_inicial = cuenta_data["saldo_inicial"]
                    existente.saldo_actual = cuenta_data["saldo_inicial"]
                actualizadas += 1
            else:
                session.add(CuentaContable(
                    codigo=cuenta_data["codigo"],
                    nombre=cuenta_data["nombre"],
                    clasificacion=cuenta_data["clasificacion"],
                    tipo=cuenta_data["tipo"],
                    saldo_inicial=cuenta_data["saldo_inicial"],
                    saldo_actual=cuenta_data["saldo_inicial"],
                    cuenta_padre=cuenta_data["cuenta_padre"],
                    activa=True,
                ))
                creadas += 1
        session.commit()
        return {"procesadas": len(cuentas), "creadas": creadas, "actualizadas": actualizadas}
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def crear_plantilla_catalogo() -> bytes:
    """Genera una plantilla Excel descargable para el catalogo."""
    ejemplo = pd.DataFrame([
        ["110101", "Caja", "EFECTIVO Y EQUIVALENTE AL EFECTIVO", "ACTIVO", 0.0, "1101"],
        ["310101", "Capital social", "CAPITAL SOCIAL", "CAPITAL", 0.0, "3101"],
    ], columns=COLUMNAS_PLANTILLA)
    salida = BytesIO()
    with pd.ExcelWriter(salida, engine="openpyxl") as escritor:
        ejemplo.to_excel(escritor, index=False, sheet_name="Catalogo")
    return salida.getvalue()
