"""
extractor.py — Extracción de Texto de Documentos (OCR)
Usa Pillow + pytesseract para procesar facturas y comprobantes.
"""

import os
import re
from pathlib import Path
from typing import Optional
from datetime import datetime

from PIL import Image, ImageEnhance, ImageFilter
import pytesseract

from app.base_datos.database import DocumentoOCR, get_session


# Configurar ruta de Tesseract (Windows)
TESSERACT_CMD = os.getenv("TESSERACT_CMD", r"C:\Program Files\Tesseract-OCR\tesseract.exe")
if Path(TESSERACT_CMD).exists():
    pytesseract.pytesseract.tesseract_cmd = TESSERACT_CMD


def preprocesar_imagen(imagen: Image.Image) -> Image.Image:
    """
    Preprocesa la imagen para mejorar la calidad del OCR:
    escala de grises, contraste y nitidez.
    """
    # Convertir a escala de grises
    imagen = imagen.convert("L")
    # Aumentar contraste
    enhancer = ImageEnhance.Contrast(imagen)
    imagen = enhancer.enhance(2.0)
    # Nitidez
    imagen = imagen.filter(ImageFilter.SHARPEN)
    # Redimensionar si es muy pequeña
    w, h = imagen.size
    if w < 800:
        factor = 800 / w
        imagen = imagen.resize((int(w * factor), int(h * factor)), Image.LANCZOS)
    return imagen


def extraer_texto(ruta_imagen: str, idioma: str = "spa") -> str:
    """
    Extrae texto de una imagen usando pytesseract.

    Args:
        ruta_imagen: Ruta al archivo de imagen.
        idioma: Código de idioma para Tesseract (default: "spa" para español).

    Returns:
        Texto extraído como string.

    Raises:
        FileNotFoundError: Si el archivo no existe.
        RuntimeError: Si Tesseract no está instalado.
    """
    ruta = Path(ruta_imagen)
    if not ruta.exists():
        raise FileNotFoundError(f"Archivo no encontrado: {ruta_imagen}")

    try:
        imagen = Image.open(ruta)
        imagen_procesada = preprocesar_imagen(imagen)
        texto = pytesseract.image_to_string(
            imagen_procesada,
            lang=idioma,
            config="--psm 6 --oem 3"
        )
        return texto.strip()
    except pytesseract.TesseractNotFoundError:
        raise RuntimeError(
            "Tesseract no está instalado. Descárgalo en: "
            "https://github.com/UB-Mannheim/tesseract/wiki"
        )


def registrar_documento_ocr(
    ruta_imagen: str,
    tipo_documento: str = "FACTURA",
    session=None
) -> DocumentoOCR:
    """
    Extrae texto de una imagen y guarda el resultado en la base de datos.

    Returns:
        El DocumentoOCR creado en la BD.
    """
    close = session is None
    if session is None:
        session = get_session()

    try:
        texto = extraer_texto(ruta_imagen)
        nombre = Path(ruta_imagen).name

        doc = DocumentoOCR(
            nombre_archivo=nombre,
            tipo_documento=tipo_documento.upper(),
            texto_extraido=texto,
            procesado=False
        )
        session.add(doc)
        session.commit()
        session.refresh(doc)
        return doc
    except Exception:
        session.rollback()
        raise
    finally:
        if close:
            session.close()


def extraer_desde_bytes(datos: bytes, nombre: str = "imagen.jpg") -> str:
    """
    Extrae texto a partir de bytes de imagen (útil para Streamlit uploader).
    """
    import io
    imagen = Image.open(io.BytesIO(datos))
    imagen_procesada = preprocesar_imagen(imagen)
    try:
        texto = pytesseract.image_to_string(imagen_procesada, lang="spa", config="--psm 6 --oem 3")
        return texto.strip()
    except pytesseract.TesseractNotFoundError:
        return "⚠️ Tesseract no instalado. Instálalo para usar OCR."
