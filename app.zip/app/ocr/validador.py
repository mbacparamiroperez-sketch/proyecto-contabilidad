"""
validador.py — Validación de Documentos OCR
Verifica que los documentos extraídos tienen los campos mínimos requeridos.
"""

from typing import dict as Dict, List
from dataclasses import dataclass, field


@dataclass
class ResultadoValidacion:
    valido: bool
    errores: List[str] = field(default_factory=list)
    advertencias: List[str] = field(default_factory=list)
    puntaje: int = 0


def validar_documento(datos: dict) -> ResultadoValidacion:
    """
    Valida un documento parseado por OCR.

    Args:
        datos: Resultado de parsear_documento()

    Returns:
        ResultadoValidacion con errores, advertencias y puntaje.
    """
    errores = []
    advertencias = []
    puntaje = 0

    # Campos obligatorios
    if not datos.get("monto"):
        errores.append("No se encontró el monto del documento.")
    else:
        puntaje += 30
        if datos["monto"] <= 0:
            errores.append(f"Monto inválido: {datos['monto']}")

    if not datos.get("fecha"):
        advertencias.append("No se encontró la fecha del documento.")
    else:
        puntaje += 25

    if not datos.get("proveedor"):
        advertencias.append("No se identificó el proveedor/emisor.")
    else:
        puntaje += 20

    if not datos.get("numero_documento"):
        advertencias.append("No se encontró el número de documento.")
    else:
        puntaje += 15

    if datos.get("tipo_documento") == "DESCONOCIDO":
        advertencias.append("No se pudo determinar el tipo de documento.")
    else:
        puntaje += 10

    # Validaciones adicionales
    if datos.get("confianza_pct", 0) < 40:
        advertencias.append(
            f"Baja confianza en la extracción ({datos.get('confianza_pct', 0)}%). "
            "Verifique el documento manualmente."
        )

    return ResultadoValidacion(
        valido=len(errores) == 0,
        errores=errores,
        advertencias=advertencias,
        puntaje=puntaje
    )


def resumen_validacion(resultado: ResultadoValidacion) -> str:
    """Retorna un resumen legible de la validación."""
    if resultado.valido:
        estado = "✅ Documento válido"
    else:
        estado = "❌ Documento con errores"

    lineas = [f"{estado} (Puntaje: {resultado.puntaje}/100)"]
    if resultado.errores:
        lineas.append("\nErrores:")
        for e in resultado.errores:
            lineas.append(f"  • {e}")
    if resultado.advertencias:
        lineas.append("\nAdvertencias:")
        for a in resultado.advertencias:
            lineas.append(f"  ⚠️ {a}")
    return "\n".join(lineas)
