"""
parser.py — Parser de Documentos OCR
Extrae campos estructurados (monto, fecha, proveedor) del texto OCR.
"""

import re
from datetime import datetime
from typing import Optional


# ─── Patrones de extracción ──────────────────────────────────────────────────

PATRONES_MONTO = [
    r"(?:total|monto|importe|valor|subtotal)[:\s]*C?\$?\s*([\d,\.]+)",
    r"C\$\s*([\d,\.]+)",
    r"\$\s*([\d,\.]+)",
    r"(?:^|\s)([\d]{1,3}(?:[,\.][\d]{3})+(?:[,\.][\d]{2})?)\s*$",
]

PATRONES_FECHA = [
    r"(\d{1,2})[/\-\.](\d{1,2})[/\-\.](\d{2,4})",
    r"(\d{1,2})\s+de\s+(\w+)\s+de\s+(\d{4})",
    r"(\d{4})[/\-\.](\d{1,2})[/\-\.](\d{1,2})",
]

MESES_ES = {
    "enero": 1, "febrero": 2, "marzo": 3, "abril": 4,
    "mayo": 5, "junio": 6, "julio": 7, "agosto": 8,
    "septiembre": 9, "octubre": 10, "noviembre": 11, "diciembre": 12
}

TIPOS_DOCUMENTO = ["FACTURA", "RECIBO", "COMPROBANTE", "NOTA DE DÉBITO", "NOTA DE CRÉDITO", "PROFORMA"]


def extraer_monto(texto: str) -> Optional[float]:
    """Extrae el monto principal del documento."""
    texto_lower = texto.lower()
    montos = []

    for patron in PATRONES_MONTO:
        matches = re.finditer(patron, texto_lower, re.IGNORECASE | re.MULTILINE)
        for m in matches:
            try:
                valor_str = m.group(1).replace(",", "").replace(" ", "")
                valor = float(valor_str)
                if valor > 0:
                    montos.append(valor)
            except (ValueError, IndexError):
                continue

    if not montos:
        return None
    # Retornar el monto más grande (generalmente el total)
    return max(montos)


def extraer_fecha(texto: str) -> Optional[datetime]:
    """Extrae la fecha del documento."""
    for patron in PATRONES_FECHA:
        match = re.search(patron, texto, re.IGNORECASE)
        if match:
            try:
                grupos = match.groups()
                if len(grupos) == 3:
                    # Verificar si el mes es texto (español)
                    if any(mes in grupos[1].lower() for mes in MESES_ES if isinstance(grupos[1], str)):
                        dia = int(grupos[0])
                        mes = MESES_ES.get(grupos[1].lower(), 1)
                        anio = int(grupos[2])
                    else:
                        parte1, parte2, parte3 = int(grupos[0]), int(grupos[1]), int(grupos[2])
                        # Determinar formato
                        if parte1 > 31:  # YYYY-MM-DD
                            anio, mes, dia = parte1, parte2, parte3
                        elif parte3 > 31:  # DD/MM/YYYY
                            dia, mes, anio = parte1, parte2, parte3
                        else:  # DD/MM/YY
                            dia, mes = parte1, parte2
                            anio = 2000 + parte3 if parte3 < 100 else parte3

                    if 1 <= mes <= 12 and 1 <= dia <= 31:
                        return datetime(anio, mes, dia)
            except (ValueError, OverflowError):
                continue

    return None


def extraer_proveedor(texto: str) -> Optional[str]:
    """Intenta extraer el nombre del proveedor/emisor del documento."""
    lineas = [l.strip() for l in texto.split("\n") if l.strip()]

    for linea in lineas[:5]:  # Las primeras líneas suelen tener el nombre
        if len(linea) > 5 and not re.match(r"^[\d\s\-\/\.]+$", linea):
            if any(keyword in linea.upper() for keyword in ["S.A.", "CIA", "COMPAÑIA", "EMPRESA", "RUC", "NIT"]):
                return linea[:200]

    # Buscar después de palabras clave
    for keyword in ["proveedor:", "emisor:", "de:", "nombre:"]:
        idx = texto.lower().find(keyword)
        if idx >= 0:
            resto = texto[idx + len(keyword):].strip()
            primera_linea = resto.split("\n")[0].strip()
            if primera_linea:
                return primera_linea[:200]

    return lineas[0][:200] if lineas else None


def extraer_numero_documento(texto: str) -> Optional[str]:
    """Extrae el número de factura/comprobante."""
    patrones = [
        r"(?:factura|recibo|comprobante|no\.?|n°|num\.?)[:\s#]*([A-Z0-9\-]{3,20})",
        r"(?:F|R|C)[–\-]?\d{3,}",
    ]
    for patron in patrones:
        match = re.search(patron, texto, re.IGNORECASE)
        if match:
            return match.group(1) if match.lastindex else match.group(0)
    return None


def detectar_tipo_documento(texto: str) -> str:
    """Detecta el tipo de documento por palabras clave."""
    texto_upper = texto.upper()
    for tipo in TIPOS_DOCUMENTO:
        if tipo in texto_upper:
            return tipo
    return "DESCONOCIDO"


def parsear_documento(texto: str) -> dict:
    """
    Parsea un texto OCR y extrae todos los campos estructurados.

    Returns:
        Dict con: tipo_documento, numero, monto, fecha, proveedor, confianza
    """
    if not texto:
        return {"error": "Texto vacío"}

    monto = extraer_monto(texto)
    fecha = extraer_fecha(texto)
    proveedor = extraer_proveedor(texto)
    numero = extraer_numero_documento(texto)
    tipo = detectar_tipo_documento(texto)

    # Calcular confianza (qué campos se encontraron)
    campos_encontrados = sum([
        monto is not None,
        fecha is not None,
        proveedor is not None,
        numero is not None,
        tipo != "DESCONOCIDO"
    ])
    confianza = round(campos_encontrados / 5 * 100)

    return {
        "tipo_documento": tipo,
        "numero_documento": numero,
        "monto": monto,
        "fecha": fecha.strftime("%Y-%m-%d") if fecha else None,
        "proveedor": proveedor,
        "confianza_pct": confianza,
        "texto_original_longitud": len(texto),
    }
