# Módulo OCR — Extracción de texto de documentos
